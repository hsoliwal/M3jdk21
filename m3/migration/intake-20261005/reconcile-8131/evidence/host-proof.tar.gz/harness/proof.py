#!/usr/bin/env python3
"""Bounded exact-8131 host integration proof using the retained host proof tools."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import py_compile
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

STAGES = ('lint', 'compile', 'test', 'runtime')
TASK = 'm3/migration/intake-20261005/reconcile-8131'
REGISTRY = 'm3/docs/name-mapping.json'
MIGRATION = 'm3/migration/migration.py'
INSTALLER = 'm3/migration/recipe.py'
JCC_TEST = 'm3/migration/test/test_jcc_handoff_packet.py'
JCC_PROFILE_TEST = 'm3/migration/test/test_jcc_handoff_context_profiles.py'
JCC_PLAN = ('m3/tooling/migration-recipes/src/main/resources/com/m3/rewrite/backport/'
            'jdk21-hash-pinned-text/jcc-handoff-20261005/plan-intake-8131.json')
INTAKE_PLAN = 'm3/migration/intake-20261005/crate/plan.json'
TARGETS = {REGISTRY, JCC_TEST, JCC_PROFILE_TEST, JCC_PLAN}
SOURCE = '99221b0f25a1b09c32855d76e295b816f632a46b'
BASE = 'ccb4ace7f7d79f97ae2d9600de55960504cc3c21'
MASTER = {'commit': '8131f535300c005afd27443d0281ede11198522f',
          'tree': '8a87d42532c93117f88f8e49abc728f3e49a8118'}
HEAD = {'commit': 'a73202a02577d3e3242a390b962fd3e08b691b60',
        'tree': 'a3ddbb9adba0023fea585d46bfc0bb74eb58a199'}
PARENT_RESULT = '077aef9e67566ae1e2fe3eb552c9fa5880b582f2bd9ea44dfb39b2d8e6babfbc'
PARENT_HELPER = 'b6646c465ba63df18b4e2b23b615966e5c7263f3353f0a6f1665d7691923fe8c'
STAGE_HELPER = '349234ce404067947b4bb9ade2d54897b19915524262358a45236b222b823ddd'
ORIGINAL_PACKET = '109173cb43fd91e084415284083d0d0ff92a1039a0b21216b7336c0a2c3dcf2e'
ORIGINAL_RECEIPT = 'ad1aa88119d8dbf5ab5a3fc64a43bd67bc67df8aadcde9139c663b15a042f1c2'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(content):
    return hashlib.sha256(content).hexdigest()


def relative(value):
    require(isinstance(value, str) and value and '\\' not in value and '\x00' not in value,
            'canonical relative path required')
    path = PurePosixPath(value)
    require(not path.is_absolute() and str(path) == value and '..' not in path.parts,
            'unsafe relative path: ' + value)
    return value


def helper(path):
    require(path.is_file() and not path.is_symlink() and sha(path.read_bytes()) == PARENT_HELPER,
            'exact retained helper required before import')
    spec = importlib.util.spec_from_file_location('_retained_intake_proof', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_parent(parent, retained):
    require(sha((parent / 'RESULT.json').read_bytes()) == PARENT_RESULT, 'parent result drift')
    require(sha((parent / 'harness/proof.py').read_bytes()) == PARENT_HELPER, 'parent helper drift')
    require(sha((parent / 'harness/run_stage.py').read_bytes()) == STAGE_HELPER, 'retained stage helper drift')
    config = retained.verify_inputs(parent)
    result = retained.load(parent / 'RESULT.json')
    require(result['status'] == 'PASS_BOUNDED_HOST_TOOL_TASK_PROJECT'
            and result['realPortableReceiptAccepted'] is True, 'successful actual parent required')
    for path, digest in result['evidence'].items():
        require(sha((parent / relative(path)).read_bytes()) == digest, 'parent evidence drift: ' + path)
    return config


def source_inventory(root, retained):
    result = []
    require(root.is_dir() and not root.is_symlink(), 'regular context directory required')
    for path in retained.files(root):
        require(not path.is_symlink(), 'context symlink: ' + str(path))
        name = path.relative_to(root).as_posix()
        result.append(dict(retained.row(path, name), gitBlob=retained.blob(path.read_bytes())))
    return sorted(result, key=lambda row: row['path'])


def check_manifest(manifest):
    require(manifest['schema'] == 'm3.reconcile-8131-proof/1'
            and manifest['sourceCommit'] == SOURCE and manifest['targetCommit'] == BASE
            and manifest['integrationMaster'] == MASTER and manifest['publicationHead'] == HEAD,
            'exact integration and historical qualification identities required')
    require(manifest['parent'] == {'resultSHA256': PARENT_RESULT, 'helperSHA256': PARENT_HELPER},
            'parent custody identity')
    require(manifest['task'] == TASK and manifest['expectedUnittestMethods'] == 108,
            'bounded task and exact test inventory')
    require(manifest['authored'] == {'union': REGISTRY, 'packet': TASK + '/packet.json',
                                    'report': TASK + '/derivation.json'}
            and manifest['previous'] == TASK + '/inputs/master.json', 'authored integration paths')
    for path in (manifest['plan'], manifest['original']['packet'], manifest['original']['receipt']):
        relative(path)
    require(manifest['original']['receiptSHA256'] == ORIGINAL_RECEIPT, 'original review receipt identity')
    rows = manifest['files']
    require(rows and [row['path'] for row in rows] == sorted({row['path'] for row in rows}),
            'ordered distinct complete context inventory')
    for row in rows:
        relative(row['path'])
        require(set(row) == {'path', 'sha256', 'bytes', 'gitBlob'}
                and type(row['bytes']) is int and row['bytes'] >= 0, 'context row shape')


def plan_rows(source, manifest, retained):
    path = source / manifest['plan']
    plan = retained.load(path)
    unsigned = {key: value for key, value in plan.items() if key != 'plan_sha256'}
    canonical = (json.dumps(unsigned, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()
    require(plan['schema'] == 'm3.sealed-install/1' and sha(canonical) == plan['plan_sha256'], 'integration plan seal')
    rows = plan['outputs']
    require(len(rows) == 4 and {row['path'] for row in rows} == TARGETS, 'four exact integration targets')
    for row in rows:
        require(row['after'] is not None, 'integration cannot delete a target')
        require((row['before'] is None) == (row['path'] in {JCC_PROFILE_TEST, JCC_PLAN}),
                'exact replacement/addition inventory')
        for state in ('before', 'after'):
            image = row[state]
            if image is not None:
                require(set(image) == {'resource', 'sha256'}, 'retained before/after image shape')
                content = (path.parent / relative(image['resource'])).read_bytes()
                require(sha(content) == image['sha256'], 'integration image drift')
        require(sha((source / row['path']).read_bytes()) == row['after']['sha256'], 'context is not integration postimage')
    return path, rows


def prepare(args):
    parent = args.parent.resolve()
    retained = helper(parent / 'harness/proof.py')
    old_config = verify_parent(parent, retained)
    context = args.context.resolve()
    manifest = retained.load(args.manifest)
    check_manifest(manifest)
    require(source_inventory(context, retained) == manifest['files'], 'context differs from reviewed manifest')
    plan_rows(context, manifest, retained)
    require(sha((context / manifest['original']['packet']).read_bytes()) == ORIGINAL_PACKET
            and sha((context / manifest['original']['receipt']).read_bytes()) == ORIGINAL_RECEIPT,
            'original portable evidence drift')
    proof = args.proof.absolute()
    require(not os.path.lexists(proof) and not any(p.is_symlink() for p in proof.parents), 'fresh canonical proof required')
    proof.mkdir(parents=True)
    shutil.copytree(context, proof / 'source')
    retained.copy(args.manifest, proof / 'authority/integration-manifest.json')
    retained.copy(parent / 'RESULT.json', proof / 'authority/parent-RESULT.json')
    retained.copy(Path(__file__).resolve(), proof / 'harness/proof.py')
    retained.copy(parent / 'harness/proof.py', proof / 'harness/parent-proof.py')
    retained.copy(parent / 'harness/run_stage.py', proof / 'harness/run_stage.py')
    retained.copy(parent / 'harness/empty-settings.xml', proof / 'harness/empty-settings.xml')
    config = {key: old_config[key] for key in ('python', 'java', 'maven', 'm2')}
    config.update(proof=str(proof), parent=str(parent), expectedTests=108,
                  stagePythonCachePrefix=str(proof / 'unused-python-cache'))
    retained.write(proof / 'config.json', config)
    retained.write(proof / 'commands.json', {stage: [config['python'], str(proof / 'harness/proof.py'), stage,
                                                   '--proof', str(proof)] for stage in STAGES})
    sets = {name: retained.tree_rows(proof / name) for name in ('source', 'authority', 'harness')}
    retained.write(proof / 'source-context.json', sets)
    retained.write(proof / 'PATCH.json', {'status': 'SEALED_BEFORE_LINT', 'gatesRun': False,
                   'sourceCommit': SOURCE, 'targetCommit': BASE, 'integrationMaster': MASTER,
                   'publicationHead': HEAD, 'parentResultSHA256': PARENT_RESULT,
                   'integrationManifestSHA256': sha((proof / 'authority/integration-manifest.json').read_bytes()),
                   'commandsSHA256': sha((proof / 'commands.json').read_bytes()),
                   'effectiveOutputAbsent': not (proof / 'installed').exists(), 'productWrites': 0})
    inputs = [retained.row(path) for name in sets for path in retained.files(proof / name)]
    inputs += [retained.row(proof / name) for name in ('config.json', 'commands.json', 'source-context.json', 'PATCH.json')]
    inputs += [retained.row(parent / name) for name in ('RESULT.json', 'config.json', 'inputs.json',
                                                      'harness/proof.py', 'harness/run_stage.py')]
    require(len({row['path'] for row in inputs}) == len(inputs), 'duplicate sealed input')
    retained.write(proof / 'inputs.json', sorted(inputs, key=lambda row: row['path']))
    verify_parent(parent, retained)
    require(source_inventory(proof / 'source', retained) == manifest['files'], 'snapshot copy drift')
    print(json.dumps({'state': 'PREPARED_NOT_EXECUTED', 'proof': str(proof),
                      'inputsSHA256': sha((proof / 'inputs.json').read_bytes()), 'sourceFiles': len(manifest['files'])}))


def verify_inputs(proof, retained):
    retained.check_rows(retained.load(proof / 'inputs.json'))
    for name, rows in retained.load(proof / 'source-context.json').items():
        require(retained.tree_rows(proof / name) == rows, 'exact sealed set drift: ' + name)
    config = retained.load(proof / 'config.json')
    verify_parent(Path(config['parent']), retained)
    require(str(Path(sys.executable).absolute()) == config['python'] and str(proof) == config['proof'],
            'exact proof path and retained interpreter required')
    require(not os.path.lexists(config['stagePythonCachePrefix']), 'unexpected Python cache output')
    manifest = retained.load(proof / 'authority/integration-manifest.json')
    check_manifest(manifest)
    require(source_inventory(proof / 'source', retained) == manifest['files'], 'source membership or blob drift')
    return config, manifest


def python_sources(source):
    return sorted({*(source / 'm3/migration').glob('*.py'),
                   *(source / 'm3/migration/test').glob('test_*.py'),
                   source / TASK / 'derive.py', *(source / TASK / 'test').glob('test_*.py')})


def lint(proof, config, manifest, retained):
    source = proof / 'source'
    ast.parse((proof / 'harness/proof.py').read_bytes(), filename=str(proof / 'harness/proof.py'))
    methods, counts = [], {'migration': 0, 'local': 0}
    for path in python_sources(source):
        parsed = ast.parse(path.read_bytes(), filename=str(path))
        if path.name.startswith('test_') and path.parent in {source / 'm3/migration/test', source / TASK / 'test'}:
            group = 'local' if path.parent == source / TASK / 'test' else 'migration'
            for cls in parsed.body:
                if isinstance(cls, ast.ClassDef):
                    found = [path.stem + '.' + cls.name + '.' + node.name for node in cls.body
                             if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
                    methods.extend(found)
                    counts[group] += len(found)
    require(len(methods) == len(set(methods)) == config['expectedTests'] == 108,
            'exact 108-method test inventory')
    require(counts == {'migration': 102, 'local': 6}, 'two discovery inventory counts')
    for path in retained.files(source / TASK):
        if path.suffix == '.json':
            retained.load(path)
        elif path.suffix == '.xml':
            ET.parse(path)
    retained.load(source / REGISTRY)
    retained.load(source / JCC_PLAN)
    plan_rows(source, manifest, retained)
    retained.write(proof / 'lint-report.json', {'pythonSources': len(python_sources(source)),
                                              'testMethods': sorted(methods), 'discoveryCounts': counts})


def compile_sources(proof, config, manifest, retained):
    destination = proof / 'target/pyc'
    require(not destination.exists(), 'compiled output exists')
    destination.mkdir(parents=True)
    for index, path in enumerate(python_sources(proof / 'source')):
        py_compile.compile(str(path), cfile=str(destination / (str(index) + '.pyc')), doraise=True)
    retained.write(proof / 'compiled-artifacts.json', retained.tree_rows(destination))


def environment(config, retained, jcc_root=None):
    result = retained.environment(config)
    result.pop('M3_JCC_CANDIDATE_ROOT', None)
    if jcc_root is not None:
        result['M3_JCC_CANDIDATE_ROOT'] = str(jcc_root)
    return result


def run(proof, config, retained, name, command, cwd, expected=0, jcc_root=None):
    directory = proof / 'commands'
    directory.mkdir(exist_ok=True)
    stdout, stderr = (directory / (name + suffix) for suffix in ('.stdout.log', '.stderr.log'))
    require(not stdout.exists() and not stderr.exists(), 'command already attempted: ' + name)
    with stdout.open('xb') as out, stderr.open('xb') as err:
        completed = subprocess.run(command, cwd=cwd, env=environment(config, retained, jcc_root),
                                   stdout=out, stderr=err, check=False)
    retained.write(directory / (name + '.json'), {'argv': command, 'cwd': str(cwd),
                   'jccCandidateRoot': str(jcc_root) if jcc_root else None,
                   'exit': completed.returncode, 'expectedExit': expected,
                   'stdoutSHA256': sha(stdout.read_bytes()), 'stderrSHA256': sha(stderr.read_bytes())})
    require(completed.returncode == expected, 'command failed: ' + name + '; see ' + str(directory))
    return stdout.read_bytes(), stderr.read_bytes()


def observed_tests(stdout, stderr):
    text = (stdout + b'\n' + stderr).decode('utf-8')
    names = []
    for name, owner, outcome in re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. (\S+)\s*$', text, re.M):
        require(outcome == 'ok', 'unittest did not pass: ' + owner)
        names.append(owner if owner.endswith('.' + name) else owner + '.' + name)
    summaries = [int(value) for value in re.findall(r'^Ran ([0-9]+) tests? in ', text, re.M)]
    return sorted(names), summaries


def test(proof, config, manifest, retained):
    require(retained.tree_rows(proof / 'target/pyc') == retained.load(proof / 'compiled-artifacts.json'),
            'compiled artifact drift')
    command = [str(Path(config['maven']) / 'bin/mvn'), '-o', '-B', '-ntp',
               '-s', str(proof / 'harness/empty-settings.xml'), '-gs', str(proof / 'harness/empty-settings.xml'),
               '-Dmaven.repo.local=' + config['m2'], '-Dm3.python=' + config['python'],
               '-f', str(proof / 'source' / TASK / 'pom.xml'), 'test']
    observed, summaries = observed_tests(*run(proof, config, retained, 'maven-test', command,
                                            proof / 'source', jcc_root=proof / 'source'))
    require(observed == retained.load(proof / 'lint-report.json')['testMethods']
            and summaries == [102, 6], 'actual two-discovery unittest inventory differs')
    retained.write(proof / 'test-report.json', {'tests': len(observed), 'methods': observed,
                   'discoveryCounts': summaries, 'failures': 0, 'errors': 0, 'skipped': 0,
                   'retainedSyntheticIntakeFixtures': True, 'actualUnionInputFixtures': True})


def runtime(proof, config, manifest, retained):
    source = proof / 'source'
    expected_after = retained.tree_rows(source)
    derived = proof / 'derived-runtime'
    run(proof, config, retained, 'derive-actual',
        [config['python'], str(source / TASK / 'derive.py'), '--inputs', str(source / TASK / 'inputs'),
         '--output', str(derived)], source)
    require({path.name for path in retained.files(derived)} == {'name-mapping.json', 'packet.json', 'derivation.json'},
            'actual derivation output set')
    for name, key in (('name-mapping.json', 'union'), ('packet.json', 'packet'), ('derivation.json', 'report')):
        require((derived / name).read_bytes() == (source / manifest['authored'][key]).read_bytes(),
                'actual derivation differs from authored bytes: ' + name)
    report = retained.load(derived / 'derivation.json')
    require(report['integrationMaster'] == MASTER and report['publicationHead'] == HEAD
            and report['masterRecordsPreserved'] == 46 and report['intakeRecordsPreserved'] == 35
            and report['uniqueRecords'] == 81, 'integration derivation provenance')

    original_plan, rows = plan_rows(source, manifest, retained)
    installed = proof / 'installed'
    require(not installed.exists(), 'installation destination exists')
    shutil.copytree(source, installed)
    for row in rows:
        path = installed / row['path']
        if row['before'] is None:
            path.unlink()
        else:
            path.write_bytes((original_plan.parent / row['before']['resource']).read_bytes())
    before = retained.tree_rows(installed)
    installer = installed / INSTALLER
    require(sha(installer.read_bytes()) == sha((Path(config['parent']) / 'baseline' / INSTALLER).read_bytes()),
            'actual retained installer changed')

    def recipe(name, mode, root=installed, expected=0):
        out, err = run(proof, config, retained, name,
                       [config['python'], str(installer), mode, '--plan', str(original_plan), '--root', str(root)],
                       proof, expected)
        return out, err

    require(json.loads(recipe('installer-before', 'check')[0])['state'] == 'before', 'installer before state')
    refused_root = proof / 'installer-refusal'
    shutil.copytree(installed, refused_root)
    (refused_root / REGISTRY).write_bytes((refused_root / REGISTRY).read_bytes() + b'\n# deliberately foreign destination\n')
    refused_before = retained.tree_rows(refused_root)
    stdout, stderr = recipe('installer-foreign-refusal', 'apply', refused_root, 2)
    require(not stdout and b'REFUSED: destination drift:' in stderr
            and retained.tree_rows(refused_root) == refused_before, 'foreign destination refusal wrote output')
    applied = json.loads(recipe('installer-apply', 'apply')[0])
    require(applied['writes'] == 4 and retained.tree_rows(installed) == expected_after,
            'installer must publish exactly four reviewed outputs and preserve all other files')
    require(json.loads(recipe('installer-fixedpoint', 'apply')[0])['writes'] == 0, 'installer fixed point')
    require(json.loads(recipe('installer-after', 'check')[0])['state'] == 'after', 'installer after state')
    require(json.loads(recipe('installer-rollback', 'rollback')[0])['writes'] == 4
            and retained.tree_rows(installed) == before, 'exact four-target rollback')
    require(json.loads(recipe('installer-reapply', 'apply')[0])['writes'] == 4
            and retained.tree_rows(installed) == expected_after, 'exact four-target reapplication')

    validator = installed / MIGRATION
    for mode, code in (('validate', 0), ('complete', 2)):
        stdout, _ = run(proof, config, retained, 'canonical-' + mode,
                        [config['python'], str(validator), mode, str(installed),
                         '--previous', str(installed / manifest['previous'])], installed, code)
        require(b'MIGRATION_MANIFEST_VALID completion=INCOMPLETE' in stdout, 'bounded canonical validation')
        require(retained.tree_rows(installed) == expected_after, 'canonical validation wrote installed files')

    # Execute all six retained behavior bodies under each permitted validator;
    # the separate eight profile controls cover setup selection and refusals.
    intake_plan_path = source / INTAKE_PLAN
    intake_plan = retained.load(intake_plan_path)
    migration_rows = [row for row in intake_plan['outputs'] if row['path'] == MIGRATION]
    require(len(migration_rows) == 1, 'one retained migration validator output')
    jcc_methods = [name for name in retained.load(proof / 'lint-report.json')['testMethods']
                   if name.startswith('test_jcc_handoff_packet.JccHandoffPacketTests.')]
    require(len(jcc_methods) == 6, 'six retained JCC behavior methods')
    jcc_roots = {}
    for state in ('before', 'after'):
        root = proof / ('jcc-' + state)
        shutil.copytree(source, root)
        image = migration_rows[0][state]
        content = (intake_plan_path.parent / relative(image['resource'])).read_bytes()
        require(sha(content) == image['sha256'], 'retained JCC validator image drift')
        (root / MIGRATION).write_bytes(content)
        frozen = retained.tree_rows(root)
        observed, summaries = observed_tests(*run(proof, config, retained, 'jcc-' + state,
            [config['python'], '-m', 'unittest', 'discover', '-s', str(root / 'm3/migration/test'),
             '-p', 'test_jcc_handoff_packet.py', '-v'], root, jcc_root=root))
        require(observed == jcc_methods and summaries == [6], 'JCC behavior profile inventory')
        require(retained.tree_rows(root) == frozen, 'JCC behavior execution modified profile context')
        jcc_roots[state] = {'tests': 6, 'validatorSHA256': image['sha256'], 'files': frozen}

    receipts = proof / 'receipts'
    receipts.mkdir()
    original_packet = installed / manifest['original']['packet']
    refused = receipts / 'original-authority-refused.json'
    stdout, stderr = run(proof, config, retained, 'original-packet-current-authority-refusal',
                        [config['python'], str(validator), 'intake', str(installed),
                         '--intake-packet', str(original_packet), '--expected-sha256', ORIGINAL_PACKET,
                         '--output', str(refused)], installed, 2)
    require(not stdout and b'intake: canonical mapping binding' in stderr and not os.path.lexists(refused)
            and retained.tree_rows(installed) == expected_after,
            'old packet must refuse the union authority without writes')

    historical = proof / 'historical'
    shutil.copytree(source, historical)
    (historical / REGISTRY).write_bytes((source / TASK / 'inputs/head.json').read_bytes())
    historical_before = retained.tree_rows(historical)
    stdout, _ = run(proof, config, retained, 'historical-original-packet-replay',
                    [config['python'], str(historical / MIGRATION), 'intake', str(historical),
                     '--intake-packet', str(historical / manifest['original']['packet']),
                     '--expected-sha256', ORIGINAL_PACKET], historical)
    require(sha(stdout) == ORIGINAL_RECEIPT
            and stdout == (source / manifest['original']['receipt']).read_bytes(), 'exact historical review receipt replay')
    historical_receipt_sha = sha(stdout)
    require(retained.tree_rows(historical) == historical_before, 'historical replay wrote files')

    packet = installed / manifest['authored']['packet']
    packet_sha = sha(packet.read_bytes())
    command = [config['python'], str(validator), 'intake', str(installed),
               '--intake-packet', str(packet), '--expected-sha256', packet_sha]
    receipt_path = receipts / 'review-receipt.json'
    stdout, _ = run(proof, config, retained, 'derived-packet-intake', command + ['--output', str(receipt_path)], installed)
    require(not stdout and retained.tree_rows(installed) == expected_after, 'review admission changed installed files')
    receipt_bytes = receipt_path.read_bytes()
    receipt = retained.load(receipt_path)
    original = retained.load(source / manifest['original']['receipt'])
    require(receipt['state'] == 'RECEIVED_FOR_REVIEW' and receipt['outputs'] == 35
            and receipt['source'] == original['source'] and receipt['target'] == original['target']
            and receipt['authority']['sha256'] == sha((installed / REGISTRY).read_bytes())
            and receipt['packetSHA256'] == packet_sha, 'derived bounded review receipt identity')
    for flag in ('wholeSourceTreeCovered', 'dependencyClosureComplete', 'originalToolchainCustodyRevalidated', 'runtimeAccepted'):
        require(receipt[flag] is False, 'acceptance scope changed: ' + flag)
        if flag in report:
            require(report[flag] is False, 'derivation report scope changed: ' + flag)
    require(receipt['productWrites'] == report['productWrites'] == 0
            and report['canonicalProductionApplied'] is False, 'product or canonical acceptance changed')
    for index in (1, 2):
        stdout, _ = run(proof, config, retained, 'derived-packet-replay-' + str(index), command, installed)
        require(stdout == receipt_bytes and retained.tree_rows(installed) == expected_after,
                'derived receipt replay is not byte-identical and read-only')
    wrong_sha = ('0' if packet_sha[0] != '0' else '1') + packet_sha[1:]
    wrong_output = receipts / 'wrong-seal-refused.json'
    stdout, stderr = run(proof, config, retained, 'derived-packet-wrong-seal',
                        command[:-1] + [wrong_sha, '--output', str(wrong_output)], installed, 2)
    require(not stdout and b'MIGRATION_REFUSED: intake packet seal drift' in stderr
            and not os.path.lexists(wrong_output) and retained.tree_rows(installed) == expected_after,
            'wrong-seal refusal changed output')
    retained.write(proof / 'runtime-report.json', {'state': 'INTEGRATION_REVIEW_RECEIPT',
                   'integrationMaster': MASTER, 'publicationHead': HEAD,
                   'sourceCommit': SOURCE, 'targetCommit': BASE, 'uniqueRegistryRecords': 81,
                   'unionSHA256': sha((installed / REGISTRY).read_bytes()),
                   'originalPacketSHA256': ORIGINAL_PACKET, 'parentResultSHA256': PARENT_RESULT,
                   'installerWrites': 4, 'fixedPointWrites': 0, 'rollbackWrites': 4, 'reapplyWrites': 4,
                   'installerRefusalExit': 2, 'canonicalValidationExit': 0, 'canonicalCompleteExit': 2,
                   'originalAuthorityRefusalExit': 2, 'historicalReceiptSHA256': historical_receipt_sha,
                   'derivedPacketSHA256': packet_sha, 'derivedReceiptSHA256': sha(receipt_bytes),
                   'readOnlyReplays': 2, 'wrongSealExit': 2, 'jccProfiles': jcc_roots,
                   'installedFiles': expected_after, 'historicalFiles': historical_before,
                   'installerRefusalFiles': refused_before, 'derivedFiles': retained.tree_rows(derived),
                   'receiptFiles': retained.tree_rows(receipts), 'integrationReceiptAccepted': True,
                   'wholeSourceTreeCovered': False, 'dependencyClosureComplete': False,
                   'originalToolchainCustodyRevalidated': False, 'runtimeAccepted': False,
                   'canonicalProductionApplied': False, 'productWrites': 0})


def verify_runtime_sets(proof, retained):
    report = retained.load(proof / 'runtime-report.json')
    for directory, field in (('installed', 'installedFiles'), ('historical', 'historicalFiles'),
                              ('installer-refusal', 'installerRefusalFiles'), ('derived-runtime', 'derivedFiles'),
                              ('receipts', 'receiptFiles')):
        require(retained.tree_rows(proof / directory) == report[field], 'runtime output membership drift: ' + directory)
    for state, data in report['jccProfiles'].items():
        require(retained.tree_rows(proof / ('jcc-' + state)) == data['files'], 'JCC profile output drift')
    require(report['integrationReceiptAccepted'] is True and report['productWrites'] == 0,
            'runtime integration receipt did not complete')


def verify(proof, retained):
    config, manifest = verify_inputs(proof, retained)
    require(not (proof / 'RESULT.json').exists() and not (proof / 'chain').exists(), 'proof already attempted')
    input_sha = sha((proof / 'inputs.json').read_bytes())
    frozen = {}
    status, failed = 'STOPPED', None
    try:
        for stage in STAGES:
            require(sha((proof / 'inputs.json').read_bytes()) == input_sha, 'sealed input manifest drift')
            verify_inputs(proof, retained)
            for name, digest in frozen.items():
                require(sha((proof / name).read_bytes()) == digest, 'prior evidence drift: ' + name)
            command = [config['python'], str(proof / 'harness/run_stage.py'), '--chain', str(proof / 'chain'),
                       '--stage', stage, '--cwd', str(proof), '--source-manifest', str(proof / 'inputs.json'), '--']
            command += retained.load(proof / 'commands.json')[stage]
            code = subprocess.run(command, env=environment(config, retained), check=False).returncode
            verify_inputs(proof, retained)
            require(sha((proof / 'inputs.json').read_bytes()) == input_sha, 'sealed input manifest drift after stage')
            for name, digest in frozen.items():
                require(sha((proof / name).read_bytes()) == digest, 'prior evidence drift after stage: ' + name)
            if code:
                failed = stage
                break
            for directory in ('chain', 'commands', 'target/pyc', 'derived-runtime', 'receipts'):
                for path in retained.files(proof / directory):
                    frozen[path.relative_to(proof).as_posix()] = sha(path.read_bytes())
            for name in ('lint-report.json', 'compiled-artifacts.json', 'test-report.json', 'runtime-report.json'):
                if (proof / name).is_file():
                    frozen[name] = sha((proof / name).read_bytes())
        else:
            verify_runtime_sets(proof, retained)
            status = 'PASS_BOUNDED_REGISTRY_INTEGRATION'
    except Exception as error:
        failed = str(error)
    for name, digest in frozen.items():
        require(sha((proof / name).read_bytes()) == digest, 'final evidence drift: ' + name)
    for directory in ('chain', 'commands'):
        for path in retained.files(proof / directory):
            frozen[path.relative_to(proof).as_posix()] = sha(path.read_bytes())
    accepted = status == 'PASS_BOUNDED_REGISTRY_INTEGRATION'
    retained.write(proof / 'RESULT.json', {'status': status, 'failed': failed, 'inputsSHA256': input_sha,
                   'sourceCommit': SOURCE, 'targetCommit': BASE, 'integrationMaster': MASTER, 'publicationHead': HEAD,
                   'parentResultSHA256': PARENT_RESULT, 'expectedUnittestMethods': 108,
                   'integrationReceiptAccepted': accepted, 'evidence': frozen,
                   'wholeSourceTreeCovered': False, 'dependencyClosureComplete': False,
                   'originalToolchainCustodyRevalidated': False, 'runtimeAccepted': False,
                   'canonicalProductionApplied': False, 'hostSystemLibrariesSealed': False, 'productWrites': 0})
    print(json.dumps({'status': status, 'failed': failed, 'proof': str(proof)}))
    return 0 if accepted else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('prepare', 'verify') + STAGES)
    parser.add_argument('--proof', required=True, type=Path)
    parser.add_argument('--context', type=Path)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--parent', type=Path)
    args = parser.parse_args()
    if args.mode == 'prepare':
        require(args.context and args.manifest and args.parent, 'context, manifest and parent are required')
        prepare(args)
        return 0
    proof = args.proof.resolve()
    retained = helper(proof / 'harness/parent-proof.py')
    if args.mode == 'verify':
        return verify(proof, retained)
    config, manifest = verify_inputs(proof, retained)
    {'lint': lint, 'compile': compile_sources, 'test': test, 'runtime': runtime}[args.mode](proof, config, manifest, retained)
    verify_inputs(proof, retained)
    print('M3_RECONCILE_8131_' + args.mode.upper() + '_PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
