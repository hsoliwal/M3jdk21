#!/usr/bin/env python3
"""Create and execute a bounded, create-only host intake proof; never a JDK acceptance gate."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import py_compile
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

STAGES = ('lint', 'compile', 'test', 'runtime')
TASK = 'm3/migration/intake-20261005'
BASELINE = 'ccb4ace7f7d79f97ae2d9600de55960504cc3c21'
PORTABLE_PREPARER_SHA256 = 'af2c0ea782643d6860d10a3d9c35706781072a361fb74a8cf6ed4caa6236e5d6'
PORTABLE = TASK + '/portable'
PROOF_METADATA = ('RESULT.json', 'PATCH.json', 'inputs.json', 'commands.json', 'staging.json',
                  'tooling.json', 'build-artifacts.json', 'junit-report.json', 'runtime-report.json')


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def load(path):
    def invalid(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique, parse_constant=invalid)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def files(root):
    return sorted(p for p in root.rglob('*') if p.is_file() or p.is_symlink())


def row(path, relative=None):
    if path.is_symlink() and path.is_dir():
        link = os.readlink(path)
        return {'path': relative or str(path), 'sha256': sha(os.fsencode(link)),
                'bytes': len(os.fsencode(link)), 'symlink': link, 'kind': 'directory-link'}
    require(path.is_file(), 'missing file: ' + str(path))
    data = path.read_bytes()
    result = {'path': relative or str(path), 'sha256': sha(data), 'bytes': len(data)}
    if path.is_symlink():
        result['symlink'] = os.readlink(path)
    return result


def check_rows(rows, root=None):
    seen = set()
    for item in rows:
        require(item['path'] not in seen, 'duplicate file row')
        seen.add(item['path'])
        path = (root / item['path']) if root else Path(item['path'])
        require(row(path, item['path']) == item, 'input drift: ' + str(path))


def tree_rows(root):
    return sorted((row(path, path.relative_to(root).as_posix()) for path in files(root)),
                  key=lambda item: item['path'])


def copy(source, destination):
    require(source.is_file() and not source.is_symlink(), 'nonregular source: ' + str(source))
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def upstream_members(root, kind):
    """Exact file enumerations read by the pinned portable prepare.py; no parent traversal."""
    require(root.is_dir() and not root.is_symlink(), 'missing upstream input directory: ' + str(root))
    if kind == 'chain':
        paths = [p for p in root.glob('*') if p.is_file()]
    elif kind == 'runtime':
        paths = [p for p in root.glob('runtime-*') if p.is_file()]
    elif kind == 'junit':
        paths = list(root.glob('TEST-*.xml'))
    elif kind == 'candidate':
        all_paths = list(root.rglob('*'))
        require(all(not p.is_symlink() for p in all_paths), 'candidate symlink input')
        paths = [p for p in all_paths if p.is_file()]
    else:
        raise ValueError('unsupported exact upstream input set')
    return sorted(str(p) for p in paths)


def collect_upstream(candidate, bindings_path, expected_sha):
    """Freeze the current preparer's read set, not a substitute upstream proof verifier."""
    preparer = candidate / TASK / 'prepare.py'
    require(sha(preparer.read_bytes()) == PORTABLE_PREPARER_SHA256,
            'portable preparer changed; review its read set before a fresh runner')
    require(bindings_path.is_absolute() and not bindings_path.is_symlink(), 'absolute regular binding file required')
    require(re.fullmatch('[0-9a-f]{64}', expected_sha or '')
            and sha(bindings_path.read_bytes()) == expected_sha, 'upstream binding seal drift')
    bindings = load(bindings_path)
    require(set(bindings) == {'schema', 'lanes'} and bindings['schema'] == 'm3.synexia-intake-bindings/1',
            'exact upstream binding shape')
    plan = load(candidate / TASK / 'output-plan.json')
    require(plan.get('status') == 'ACTUAL_OUTPUT_IDENTITIES_PENDING_INTAKE',
            'final reviewed actual-output plan required before real binding preparation')
    grouped = {}
    for item in plan['expectedOutputs']:
        grouped.setdefault(item['lane'], []).append(item)
    require(set(bindings['lanes']) == set(grouped), 'complete current upstream lane set required')
    require(plan['target']['commit'] == BASELINE, 'portable downstream baseline mismatch')
    captured, sets, absent, proofs = {}, {}, set(), {}

    def capture(path):
        require(path.is_file() and not path.is_symlink(), 'regular external input required: ' + str(path))
        require(not any(p.is_symlink() for p in path.parents), 'external parent symlink: ' + str(path))
        captured[str(path)] = row(path)

    def capture_set(root, kind):
        members = upstream_members(root, kind)
        for name in members:
            capture(Path(name))
        sets[(str(root), kind)] = {'root': str(root), 'kind': kind, 'files': members}
        return members

    def capture_proof(binding):
        require(isinstance(binding, dict) and set(binding) == {'proof', 'resultSHA256'}, 'exact proof binding required')
        original = Path(binding['proof'])
        require(original.is_absolute() and str(original) == str(original.resolve()),
                'proof binding must retain an absolute canonical original path')
        require(original.is_dir() and not original.is_symlink(), 'upstream proof directory required')
        stopped = original / 'STOPPED.json'
        require(not os.path.lexists(stopped), 'stopped upstream proof cannot be bound')
        absent.add(str(stopped))
        for name in PROOF_METADATA:
            capture(original / name)
        result = load(original / 'RESULT.json')
        require(re.fullmatch('[0-9a-f]{64}', binding['resultSHA256'])
                and sha((original / 'RESULT.json').read_bytes()) == binding['resultSHA256']
                and result['status'] == 'PASS_FOCUSED_TEST_PROJECT'
                and result['baseline'] == plan['source']['commit'], 'exact successful current upstream result required')
        capture_set(original / 'chain', 'chain')
        capture_set(original, 'runtime')
        capture_set(original / 'target/surefire-reports', 'junit')
        proofs[str(original)] = {'proof': str(original), 'resultSHA256': binding['resultSHA256']}
        return original

    capture(bindings_path)
    # This closed protocol table is copied from the pinned preparer's actual manifest selection.
    protocols = {
        'com.synexia.rewrite.Mre': ('mre', {'mre'}, {'mre-v1'}),
        'com.synexia.rewrite.Mre2': ('mre', {'mre', 'mre2'}, {'mre-v2'}),
        'com.synexia.rewrite.Pcr': ('pcr', {'pcr'}, {'pcs-reconciled-v1'}),
        'com.synexia.rewrite.Mrc': ('mrc', {'mrc'}, {'mrc-v1'}),
        'com.synexia.rewrite.Mrc2': ('mrc', {'mrc', 'mrc2'}, {'mrc-v2'}),
        'com.synexia.rewrite.Mrc3': ('mrc', {'mrc', 'mrc2', 'mrc3'}, {'mrc-v3'}),
        'com.synexia.rewrite.Mrc4': ('mrc', {'mrc', 'mrc2', 'mrc4'}, {'mrc-v4'}),
        'com.synexia.rewrite.Mrp': ('mrp', {'mrp'}, {'mrp-v1', 'mrp-v2'}),
        'com.synexia.rewrite.Mrd': ('mrd', {'mrd'}, {'mrd-v1'})}
    for name, expected in sorted(grouped.items()):
        binding = bindings['lanes'][name]
        require(set(binding) == {'recipeId', 'recipe', 'consumers'} and binding['consumers'],
                'exact producer identity and consumers required')
        source = capture_proof(binding['recipe'])
        recipe_id = expected[0]['recipe']
        require(binding['recipeId'] == recipe_id, 'reviewed binding recipe identity')
        require(recipe_id in protocols and all(r['recipe'] == recipe_id for r in expected), 'one known producer per lane')
        family, lane_names, crates = protocols[recipe_id]
        require(name in lane_names, 'exact lane/protocol association')
        actual = source / 'generated-candidate'
        paths = capture_set(actual, 'candidate')
        extras = {'OUTPUT.json', 'candidate.patch'} if family != 'pcr' else set()
        expected_paths = [r['path'] for r in expected]
        require(expected_paths == sorted(set(expected_paths)), 'ordered unique reviewed lane outputs')
        relative = {Path(p).relative_to(actual).as_posix(): Path(p) for p in paths}
        require(set(relative) == set(expected_paths) | extras, 'exact upstream generated-candidate file set')
        for item in expected:
            data = relative[item['path']].read_bytes()
            require(sha(data) == item['sha256'] and blob(data) == item['gitBlob'], 'actual upstream output differs from reviewed plan')
        output = load(actual / 'OUTPUT.json') if family != 'pcr' else None
        crate = output.get('crate') if output is not None else 'pcs-reconciled-v1'
        require(crate in crates, 'exact original materializer crate')
        if output is not None:
            require(output.get('recipe') == recipe_id and output.get('baseline') == plan['source']['commit']
                    and output.get('schema') == 'synexia.' + family + '.output/1', 'original materializer identity')
        capture(source / ('sources/synexia-openrewrite-recipes/src/main/resources/'
                          'com/synexia/rewrite/hash-pinned-java/' + crate + '/manifest.tsv'))
        for consumer in binding['consumers']:
            capture_proof(consumer)
    return {'schema': 'm3.host-portable-inputs/1', 'preparerSHA256': PORTABLE_PREPARER_SHA256,
            'bindingsOriginal': str(bindings_path), 'bindingsSHA256': expected_sha,
            'source': plan['source'], 'target': plan['target'], 'lanes': sorted(grouped),
            'outputs': len(plan['expectedOutputs']), 'proofs': [proofs[k] for k in sorted(proofs)],
            'files': [captured[k] for k in sorted(captured)],
            'sets': [sets[k] for k in sorted(sets)], 'absent': sorted(absent),
            'originalToolchainCustodyRevalidated': False}


def verify_upstream(proof):
    path = proof / 'authority/upstream-inputs.json'
    if not path.exists():
        return
    inputs = load(path)
    check_rows(inputs['files'])
    for item in inputs['files']:
        source = Path(item['path'])
        require(not source.is_symlink() and not any(p.is_symlink() for p in source.parents),
                'upstream input symlink drift: ' + str(source))
    for item in inputs['sets']:
        require(upstream_members(Path(item['root']), item['kind']) == item['files'],
                'upstream consumed file set drift: ' + item['root'] + '/' + item['kind'])
    for name in inputs['absent']:
        require(not os.path.lexists(name), 'new upstream stop marker: ' + name)


def prepare(args):
    research = args.research.resolve()
    candidate = research / 'candidate-repo'
    target = args.proof.absolute()
    require(not target.exists(), 'proof path already exists; select a new lane')
    require(bool(args.bindings) == bool(args.bindings_sha256),
            '--bindings and --bindings-sha256 must be supplied together')
    upstream = collect_upstream(candidate, args.bindings.absolute(), args.bindings_sha256) if args.bindings else None
    manifest = load(research / 'candidate-manifest.json')
    publication = load(research / 'publication-plan.json')
    tree = load(research / 'tree.json')
    require(manifest['baseline'] == tree['commit'] == BASELINE and tree['truncated'] is False,
            'frozen downstream source identity')
    expected = {item['path']: item for item in manifest['candidateTargets']}
    resources = {item['path']: item for item in publication['recipeResources']}
    require(len(expected) == len(manifest['candidateTargets']) == 10, 'bounded installer targets')
    require(set(expected).isdisjoint(resources), 'resource/target overlap')
    git = {item['path']: item for item in tree['files']}
    plan_path = candidate / TASK / 'crate/plan.json'
    plan = load(plan_path)
    require(sha(plan_path.read_bytes()) == manifest['planSHA256'], 'plan bytes drift')
    unsigned = {key: value for key, value in plan.items() if key != 'plan_sha256'}
    canonical = (json.dumps(unsigned, sort_keys=True, separators=(',', ':')) + '\n').encode()
    require(sha(canonical) == plan['plan_sha256'] == manifest['planSeal'], 'plan seal drift')
    require({item['path'] for item in plan['outputs']} == set(expected), 'plan target set')
    for item in plan['outputs']:
        require(item['after']['sha256'] == expected[item['path']]['sha256']
                and item['before'] == expected[item['path']]['before'], 'plan/target image mismatch')
    target.mkdir(parents=True)
    copied = []
    for path in files(candidate):
        relative = path.relative_to(candidate).as_posix()
        require(not path.is_symlink(), 'source symlink: ' + relative)
        data = path.read_bytes()
        item = expected.get(relative) or resources.get(relative)
        if item:
            require(sha(data) == item['sha256'] and len(data) == item['bytes'], 'authored drift: ' + relative)
        else:
            require(relative in git and blob(data) == git[relative]['gitBlob'], 'noncanonical context: ' + relative)
        copy(path, target / 'source' / relative)
        if relative in git:
            baseline_data = data
            if relative in expected:
                before = expected[relative]['before']
                require(before is not None, 'addition overwrites existing source')
                baseline_data = (plan_path.parent / before['resource']).read_bytes()
                require(sha(baseline_data) == before['sha256'], 'before-image drift')
            require(blob(baseline_data) == git[relative]['gitBlob'], 'baseline blob drift: ' + relative)
            out = target / 'baseline' / relative
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(baseline_data)
        elif relative not in expected and relative not in resources:
            raise ValueError('unclassified input: ' + relative)
        copied.append(relative)
    require(set(expected) | set(resources) <= set(copied), 'missing target/resource')
    for guard in plan['guards']:
        require(sha((target / 'baseline' / guard['path']).read_bytes()) == guard['sha256'], 'guard drift')
    for name in ('candidate-manifest.json', 'publication-plan.json', 'tree.json'):
        copy(research / name, target / 'authority' / name)
    copy(args.dependencies.resolve(), target / 'authority/dependencies.json')
    copy(Path(__file__).resolve(), target / 'harness/proof.py')
    copy(args.run_stage.resolve(), target / 'harness/run_stage.py')
    if upstream is not None:
        copy(args.bindings.absolute(), target / 'authority/upstream-bindings.json')
        require(sha((target / 'authority/upstream-bindings.json').read_bytes()) == args.bindings_sha256,
                'bindings changed during preparation')
        write(target / 'authority/upstream-inputs.json', upstream)
        verify_upstream(target)
    empty = target / 'harness/empty-settings.xml'
    empty.write_text('<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"/>\n')
    tools = {}
    acquisition = load(args.dependencies)
    require(acquisition['kind'] == 'TEMPORARY_HOST_TOOL_CACHE' and acquisition['proofGatesRun'] is False,
            'dependency acquisition kind')
    for item in acquisition['artifacts']:
        path = Path(item['path'])
        actual = row(path)
        require(actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes'], 'acquired dependency drift')
        tools[str(path)] = actual
    generated_host_inputs = []
    python_root = args.python.parent.parent.resolve()
    for path in files(python_root):
        if str(path) in tools:
            continue
        relative = path.relative_to(python_root)
        cache = '__pycache__' in relative.parts and path.suffix == '.pyc' and not path.is_symlink()
        alias = relative.as_posix() == 'lib64' and path.is_symlink() and os.readlink(path) == 'lib'
        require(cache or alias, 'unacquired Python input: ' + str(path))
        tools[str(path)] = row(path)
        generated_host_inputs.append({'path': str(path), 'kind': 'generated-python-cache' if cache else 'venv-directory-alias'})
    for root in (args.java.resolve(), args.maven.resolve()):
        for path in files(root):
            tools[str(path)] = row(path)
    # Venv executable is copied; the base stdlib and extension modules remain external host inputs.
    cfg = (args.python.parent.parent / 'pyvenv.cfg').read_text()
    home = re.search(r'^home = (.+)$', cfg, re.M)
    require(home is not None, 'venv base home')
    base = Path(home.group(1)).parent
    for library in sorted((base / 'lib').glob('python*')):
        for path in files(library):
            if 'site-packages' not in path.relative_to(library).parts and '__pycache__' not in path.parts:
                tools[str(path)] = row(path)
    tool_sets = []
    for root in (args.java.resolve(), args.maven.resolve(), args.m2.resolve(), args.python.parent.parent.resolve()):
        members = [str(path) for path in files(root)]
        require(all(name in tools for name in members), 'unacquired file in tool root: ' + str(root))
        tool_sets.append({'root': str(root), 'exclude': [], 'files': members})
    for library in sorted((base / 'lib').glob('python*')):
        members = [str(path) for path in files(library)
                   if 'site-packages' not in path.relative_to(library).parts and '__pycache__' not in path.parts]
        tool_sets.append({'root': str(library), 'exclude': ['site-packages', '__pycache__'], 'files': members})
    config = {'proof': str(target), 'python': str(args.python.absolute()), 'java': str(args.java.resolve()),
              'maven': str(args.maven.resolve()), 'm2': str(args.m2.resolve()),
              'expectedTests': publication['expectedUnittestMethods'], 'baseline': BASELINE,
              'syntheticReceiptFixtures': True, 'portablePacketPending': True,
              'realPortableRequested': upstream is not None,
              'portableBindingsSHA256': upstream['bindingsSHA256'] if upstream is not None else None,
              'portableExpectedOutputs': upstream['outputs'] if upstream is not None else None,
              'hostSystemLibrariesSealed': False, 'productRuntimeAccepted': False,
              'generatedHostInputs': generated_host_inputs,
              'stagePythonCachePrefix': str(target / 'unused-python-cache')}
    write(target / 'config.json', config)
    write(target / 'tooling.json', list(sorted(tools.values(), key=lambda item: item['path'])))
    write(target / 'tooling-roots.json', tool_sets)
    sets = {name: tree_rows(target / name) for name in ('source', 'baseline', 'authority', 'harness')}
    write(target / 'source-context.json', sets)
    commands = {stage: [config['python'], str(target / 'harness/proof.py'), stage, '--proof', str(target)]
                for stage in STAGES}
    write(target / 'commands.json', commands)
    patch = {'status': 'SEALED_BEFORE_LINT', 'baseline': BASELINE, 'gatesRun': False,
             'effectiveOutputAbsent': not (target / 'installed').exists(), 'targetCount': len(expected),
             'planSeal': manifest['planSeal'], 'sourceContextSHA256': sha((target / 'source-context.json').read_bytes()),
             'toolingSHA256': sha((target / 'tooling.json').read_bytes()),
             'commandsSHA256': sha((target / 'commands.json').read_bytes()),
             'candidateManifestSHA256': sha((target / 'authority/candidate-manifest.json').read_bytes()),
             'syntheticReceiptFixtures': True, 'portablePacketPending': True}
    patch['realPortableRequested'] = upstream is not None
    patch['upstreamInputsSHA256'] = sha((target / 'authority/upstream-inputs.json').read_bytes()) if upstream is not None else None
    write(target / 'PATCH.json', patch)
    inputs = [row(path) for name in sets for path in files(target / name)]
    inputs += [row(target / name) for name in ('config.json', 'tooling.json', 'tooling-roots.json', 'source-context.json', 'commands.json', 'PATCH.json')]
    if upstream is not None:
        inputs += upstream['files']
        verify_upstream(target)
    require(len({item['path'] for item in inputs}) == len(inputs), 'duplicate sealed input path')
    write(target / 'inputs.json', sorted(inputs, key=lambda item: item['path']))
    print(json.dumps({'state': 'PREPARED_NOT_EXECUTED', 'proof': str(target),
                      'inputsSHA256': sha((target / 'inputs.json').read_bytes()), 'sourceFiles': len(copied)}))


def verify_inputs(proof):
    check_rows(load(proof / 'inputs.json'))
    verify_upstream(proof)
    sets = load(proof / 'source-context.json')
    for name, expected in sets.items():
        require(tree_rows(proof / name) == expected, 'exact source/context set drift: ' + name)
    check_rows(load(proof / 'tooling.json'))
    for item in load(proof / 'tooling-roots.json'):
        root = Path(item['root'])
        current = [str(path) for path in files(root)
                   if not set(item['exclude']).intersection(path.relative_to(root).parts)]
        require(current == item['files'], 'tool input set drift: ' + str(root))
    config = load(proof / 'config.json')
    require(config['realPortableRequested'] == (proof / 'authority/upstream-inputs.json').is_file(),
            'portable input selection drift')
    require(str(Path(sys.executable).absolute()) == config['python'], 'wrong proof interpreter')
    require(str(proof) == config['proof'], 'proof relocation requires fresh preparation')
    require(not Path(config['stagePythonCachePrefix']).exists(), 'unexpected Python cache prefix output')
    return config


def python_sources(proof):
    source = proof / 'source'
    return sorted({source / 'm3/migration/migration.py', source / 'm3/migration/recipe.py',
                   source / TASK / 'prepare.py', *(source / 'm3/migration/test').glob('test_*.py')})


def lint(proof, config):
    methods = []
    for path in python_sources(proof):
        parsed = ast.parse(path.read_bytes(), filename=str(path))
        if path.name.startswith('test_'):
            for cls in parsed.body:
                if isinstance(cls, ast.ClassDef):
                    methods += [path.stem + '.' + cls.name + '.' + node.name for node in cls.body
                                if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    require(len(methods) == config['expectedTests'] and len(set(methods)) == len(methods), 'exact expected test method count')
    for item in load(proof / 'authority/candidate-manifest.json')['candidateTargets']:
        path = proof / 'source' / item['path']
        if path.suffix == '.json':
            load(path)
        elif path.suffix == '.xml':
            ET.parse(path)
    load(proof / 'source' / TASK / 'crate/plan.json')
    write(proof / 'lint-report.json', {'pythonSources': len(python_sources(proof)), 'testMethods': sorted(methods)})


def compile_sources(proof, config):
    output = proof / 'target/pyc'
    require(not output.exists(), 'compiled output already exists')
    output.mkdir(parents=True)
    for index, source in enumerate(python_sources(proof)):
        py_compile.compile(str(source), cfile=str(output / (str(index) + '.pyc')), doraise=True)
    write(proof / 'compiled-artifacts.json', tree_rows(output))


def environment(config):
    result = dict(os.environ)
    for name in ('PYTHONPATH', 'PYTHONHOME', 'MAVEN_ARGS', 'MAVEN_OPTS', 'JAVA_TOOL_OPTIONS', 'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS', 'CLASSPATH'):
        result.pop(name, None)
    result.update({'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0', 'JAVA_HOME': config['java'],
                   'PYTHONPYCACHEPREFIX': config['stagePythonCachePrefix'],
                   'MAVEN_SKIP_RC': 'true', 'LC_ALL': 'C.UTF-8'})
    return result


def run_command(proof, config, name, command, cwd, expected=0):
    directory = proof / 'commands'
    directory.mkdir(exist_ok=True)
    stdout = directory / (name + '.stdout.log')
    stderr = directory / (name + '.stderr.log')
    require(not stdout.exists() and not stderr.exists(), 'command replay: ' + name)
    with stdout.open('xb') as out, stderr.open('xb') as err:
        completed = subprocess.run(command, cwd=cwd, env=environment(config), stdout=out, stderr=err, check=False)
    receipt = {'argv': command, 'cwd': str(cwd), 'exit': completed.returncode, 'expectedExit': expected,
               'stdoutSHA256': sha(stdout.read_bytes()), 'stderrSHA256': sha(stderr.read_bytes())}
    write(directory / (name + '.json'), receipt)
    require(completed.returncode == expected, 'command failed: ' + name + '; see ' + str(directory))
    return stdout.read_text(), stderr.read_text()


def test(proof, config):
    require(tree_rows(proof / 'target/pyc') == load(proof / 'compiled-artifacts.json'), 'compiled artifact drift')
    command = [str(Path(config['maven']) / 'bin/mvn'), '-o', '-B', '-ntp',
               '-s', str(proof / 'harness/empty-settings.xml'), '-gs', str(proof / 'harness/empty-settings.xml'),
               '-Dmaven.repo.local=' + config['m2'], '-Dm3.python=' + config['python'],
               '-f', str(proof / 'source' / TASK / 'pom.xml'), 'test']
    stdout, stderr = run_command(proof, config, 'maven-test', command, proof / 'source')
    observed = []
    for name, owner, outcome in re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. (\S+)\s*$', stdout + '\n' + stderr, re.M):
        observed.append(owner if owner.endswith('.' + name) else owner + '.' + name)
        require(outcome == 'ok', 'unittest did not pass: ' + owner)
    expected = load(proof / 'lint-report.json')['testMethods']
    require(sorted(observed) == expected, 'executed unittest inventory differs from frozen methods')
    require(re.search(r'^Ran ' + str(len(expected)) + r' tests? in ', stdout + '\n' + stderr, re.M), 'unittest summary missing')
    write(proof / 'test-report.json', {'tests': len(observed), 'failures': 0, 'errors': 0, 'skipped': 0,
                                      'methods': sorted(observed), 'syntheticReceiptFixtures': True})


def portable_runtime(proof, config, installed, preportable):
    """Exercise installed tools against actual bound outputs; produce review evidence only."""
    upstream = load(proof / 'authority/upstream-inputs.json')
    portable = installed / PORTABLE
    require(not os.path.lexists(portable), 'portable runtime destination already exists')
    preparer = installed / TASK / 'prepare.py'
    require(sha(preparer.read_bytes()) == PORTABLE_PREPARER_SHA256, 'installed portable preparer identity')
    bindings = proof / 'authority/upstream-bindings.json'
    require(sha(bindings.read_bytes()) == config['portableBindingsSHA256'] == upstream['bindingsSHA256'],
            'installed runtime binding identity')

    def unchanged_product():
        current = tree_rows(installed)
        require(not any(p.is_symlink() for p in installed.rglob('*')), 'installed output symlink')
        retained = [r for r in current if not r['path'].startswith(PORTABLE + '/')]
        require(retained == preportable, 'portable operation changed a preportable installed file or added a product file')
        return current

    def invoke(name, command, expected=0):
        verify_inputs(proof)
        unchanged_product()
        stdout, stderr = run_command(proof, config, name, command, installed, expected)
        unchanged_product()
        verify_inputs(proof)
        return stdout, stderr

    stdout, _ = invoke('portable-prepare', [config['python'], str(preparer), '--root', str(installed),
                        '--bindings', str(bindings), '--bindings-sha256', config['portableBindingsSHA256'],
                        '--out', PORTABLE])
    prepared = json.loads(stdout, object_pairs_hook=unique)
    packet = portable / 'packet.json'
    packet_sha = sha(packet.read_bytes())
    require(prepared == {'status': 'PREPARED_NOT_ADMITTED', 'packet': str(packet),
                         'packetSHA256': packet_sha, 'actualOutputFiles': config['portableExpectedOutputs'],
                         'upstreamBindingsSHA256': config['portableBindingsSHA256'], 'productWrites': 0},
            'installed preparer completion identity')
    prepared_rows = tree_rows(installed)
    validator = installed / 'm3/migration/migration.py'
    command = [config['python'], str(validator), 'intake', str(installed),
               '--intake-packet', str(packet), '--expected-sha256', packet_sha]
    receipt_path = portable / 'review-receipt.json'
    stdout, _ = invoke('portable-intake', command + ['--output', str(receipt_path)])
    require(stdout == '', 'output-file admission unexpectedly wrote stdout')
    receipt = load(receipt_path)
    require(receipt.get('schema') == 'm3.synexia-intake-receipt/1'
            and receipt.get('state') == 'RECEIVED_FOR_REVIEW'
            and receipt.get('packetSHA256') == packet_sha
            and receipt.get('source') == upstream['source'] and receipt.get('target') == upstream['target']
            and receipt.get('outputs') == config['portableExpectedOutputs']
            and sorted(r['id'] for r in receipt['lanes']) == upstream['lanes'],
            'actual installed intake did not admit the bound review packet')
    for field in ('wholeSourceTreeCovered', 'dependencyClosureComplete',
                  'originalToolchainCustodyRevalidated', 'runtimeAccepted'):
        require(receipt.get(field) is False, 'receipt exceeds bounded review scope: ' + field)
    require(type(receipt.get('productWrites')) is int and receipt['productWrites'] == 0,
            'review receipt claims product writes')
    admitted_rows = tree_rows(installed)
    expected_rows = prepared_rows + [row(receipt_path, receipt_path.relative_to(installed).as_posix())]
    require(admitted_rows == sorted(expected_rows, key=lambda item: item['path']),
            'intake changed prepared evidence beyond its one review receipt')
    receipt_bytes = receipt_path.read_bytes()
    replays = []
    for index in (1, 2):
        name = 'portable-intake-replay-' + str(index)
        invoke(name, command)
        output = proof / 'commands' / (name + '.stdout.log')
        require(output.read_bytes() == receipt_bytes, 'read-only intake replay changed receipt bytes')
        require(tree_rows(installed) == admitted_rows, 'read-only intake replay wrote installed files')
        replays.append({'command': name, 'receiptSHA256': sha(output.read_bytes()), 'productWrites': 0})
    wrong_sha = ('0' if packet_sha[0] != '0' else '1') + packet_sha[1:]
    refused = portable / 'refused-receipt.json'
    require(not os.path.lexists(refused), 'refusal destination already exists')
    wrong_command = command[:-1] + [wrong_sha, '--output', str(refused)]
    stdout, stderr = invoke('portable-intake-wrong-seal', wrong_command, 2)
    require(stdout == '' and 'MIGRATION_REFUSED: intake packet seal drift' in stderr,
            'wrong packet seal did not refuse for its exact cause')
    require(not os.path.lexists(refused) and tree_rows(installed) == admitted_rows,
            'wrong-seal refusal wrote installed output')
    report = {'schema': 'm3.host-portable-runtime/1', 'state': 'REVIEW_RECEIPT',
              'packet': packet.relative_to(proof).as_posix(), 'packetSHA256': packet_sha,
              'receipt': receipt_path.relative_to(proof).as_posix(), 'receiptSHA256': sha(receipt_bytes),
              'upstreamBindingsSHA256': config['portableBindingsSHA256'],
              'outputs': receipt['outputs'], 'lanes': upstream['lanes'], 'readOnlyReplays': replays,
              'wrongSealExit': 2, 'wrongSealOutputAbsent': True, 'preportableFilesUnchanged': True,
              'portablePacketPending': False, 'realPortableReceiptAccepted': True,
              'originalToolchainCustodyRevalidated': False, 'runtimeAccepted': False,
              'productRuntimeAccepted': False, 'canonicalProductionApplied': False, 'productWrites': 0,
              'portableFiles': tree_rows(portable), 'installedFiles': admitted_rows}
    write(proof / 'portable-runtime-report.json', report)
    return report


def runtime(proof, config):
    installed = proof / 'installed'
    require(not installed.exists(), 'runtime destination already exists')
    shutil.copytree(proof / 'baseline', installed)
    plan = proof / 'source' / TASK / 'crate/plan.json'
    installer = proof / 'baseline/m3/migration/recipe.py'
    def invoke(name, mode):
        stdout, _ = run_command(proof, config, name,
                                [config['python'], str(installer), mode, '--plan', str(plan), '--root', str(installed)], proof)
        return json.loads(stdout)
    before = invoke('installer-before', 'check')
    require(before['state'] == 'before', 'installer before state')
    applied = invoke('installer-apply', 'apply')
    manifest = load(proof / 'authority/candidate-manifest.json')
    require(applied['writes'] == len(manifest['candidateTargets']), 'installer write count')
    require(invoke('installer-fixedpoint', 'apply')['writes'] == 0, 'installer fixed point')
    require(invoke('installer-after', 'check')['state'] == 'after', 'installer after state')
    expected = {item['path']: item for item in tree_rows(proof / 'baseline')}
    for item in manifest['candidateTargets']:
        expected[item['path']] = {key: item[key] for key in ('path', 'sha256', 'bytes')}
    actual = tree_rows(installed)
    require(actual == sorted(expected.values(), key=lambda item: item['path']), 'installer changed unexpected context')
    validator = installed / 'm3/migration/migration.py'
    previous = proof / 'baseline/m3/docs/name-mapping.json'
    for command, code in (('validate', 0), ('complete', 2)):
        stdout, _ = run_command(proof, config, 'canonical-' + command,
                                [config['python'], str(validator), command, str(installed), '--previous', str(previous)], installed, code)
        require('MIGRATION_MANIFEST_VALID completion=INCOMPLETE' in stdout, 'canonical coverage boundary')
    require(tree_rows(installed) == actual, 'validation modified installed output')
    portable = portable_runtime(proof, config, installed, actual) if config['realPortableRequested'] else None
    write(proof / 'runtime-report.json', {'installerWrites': applied['writes'], 'fixedPointWrites': 0,
             'canonicalValidationExit': 0, 'canonicalCompleteExit': 2, 'installedFiles': actual,
             'portablePacketPending': portable is None, 'realPortableReceiptAccepted': portable is not None,
             'portableRuntimeSHA256': sha((proof / 'portable-runtime-report.json').read_bytes()) if portable else None,
             'finalInstalledFiles': portable['installedFiles'] if portable else actual,
             'originalToolchainCustodyRevalidated': False, 'runtimeAccepted': False,
             'canonicalProductionApplied': False, 'productRuntimeAccepted': False, 'productWrites': 0})


def verify(proof):
    config = verify_inputs(proof)
    require(not (proof / 'RESULT.json').exists() and not (proof / 'chain').exists(), 'proof already attempted')
    input_hash = sha((proof / 'inputs.json').read_bytes())
    frozen_receipts = {}
    status = 'STOPPED'
    failed = None
    try:
        for stage in STAGES:
            require(sha((proof / 'inputs.json').read_bytes()) == input_hash, 'input manifest drift')
            verify_inputs(proof)
            for name, digest in frozen_receipts.items():
                require(sha((proof / name).read_bytes()) == digest, 'prior evidence drift: ' + name)
            command = [config['python'], str(proof / 'harness/run_stage.py'), '--chain', str(proof / 'chain'),
                       '--stage', stage, '--cwd', str(proof), '--source-manifest', str(proof / 'inputs.json'), '--']
            command += load(proof / 'commands.json')[stage]
            code = subprocess.run(command, env=environment(config), check=False).returncode
            verify_inputs(proof)
            require(sha((proof / 'inputs.json').read_bytes()) == input_hash, 'input manifest drift after stage')
            for name, digest in frozen_receipts.items():
                require(sha((proof / name).read_bytes()) == digest, 'prior evidence drift after stage: ' + name)
            if code:
                failed = stage
                break
            for directory in ('chain', 'commands', 'target/pyc', 'installed/' + PORTABLE):
                for path in files(proof / directory):
                    frozen_receipts[path.relative_to(proof).as_posix()] = sha(path.read_bytes())
            for name in ('lint-report.json', 'compiled-artifacts.json', 'test-report.json',
                         'runtime-report.json', 'portable-runtime-report.json'):
                if (proof / name).exists():
                    frozen_receipts[name] = sha((proof / name).read_bytes())
        else:
            runtime_report = load(proof / 'runtime-report.json')
            require(tree_rows(proof / 'installed') == runtime_report['finalInstalledFiles'], 'final installed output drift')
            require(runtime_report['realPortableReceiptAccepted'] is config['realPortableRequested'],
                    'requested portable runtime did not complete')
            status = 'PASS_BOUNDED_HOST_TOOL_TASK_PROJECT'
    except Exception as error:
        failed = str(error)
    for name, digest in frozen_receipts.items():
        require(sha((proof / name).read_bytes()) == digest, 'final evidence drift: ' + name)
    for directory in ('chain', 'commands'):
        for path in files(proof / directory):
            frozen_receipts[path.relative_to(proof).as_posix()] = sha(path.read_bytes())
    portable_accepted = status == 'PASS_BOUNDED_HOST_TOOL_TASK_PROJECT' and config['realPortableRequested']
    write(proof / 'RESULT.json', {'status': status, 'failed': failed, 'inputsSHA256': input_hash,
          'baseline': BASELINE, 'syntheticReceiptFixtures': True, 'portablePacketPending': not portable_accepted,
          'realPortableRequested': config['realPortableRequested'],
          'realPortableReceiptAccepted': portable_accepted, 'canonicalProductionApplied': False,
          'portableBindingsSHA256': config['portableBindingsSHA256'], 'productWrites': 0,
          'originalToolchainCustodyRevalidated': False,
          'strictCanonicalAdmission': False, 'runtimeAccepted': False, 'hostSystemLibrariesSealed': False,
          'evidence': frozen_receipts})
    print(json.dumps({'status': status, 'failed': failed, 'proof': str(proof)}))
    return 0 if status.startswith('PASS_') else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('prepare', 'verify') + STAGES)
    parser.add_argument('--proof', required=True, type=Path)
    for name in ('research', 'dependencies', 'run-stage', 'python', 'java', 'maven', 'm2'):
        parser.add_argument('--' + name, type=Path)
    parser.add_argument('--bindings', type=Path)
    parser.add_argument('--bindings-sha256')
    args = parser.parse_args()
    if args.mode == 'prepare':
        require(all(getattr(args, name.replace('-', '_')) for name in ('research', 'dependencies', 'run-stage', 'python', 'java', 'maven', 'm2')), 'preparation arguments missing')
        prepare(args)
        return 0
    proof = args.proof.resolve()
    if args.mode == 'verify':
        return verify(proof)
    config = verify_inputs(proof)
    {'lint': lint, 'compile': compile_sources, 'test': test, 'runtime': runtime}[args.mode](proof, config)
    verify_inputs(proof)
    print('M3_INTAKE_' + args.mode.upper() + '_PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
