#!/usr/bin/env python3
"""Record a real command and reject out-of-order or replayed verification stages."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

STAGES = ("lint", "compile", "test", "runtime")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chain", required=True, type=Path)
    parser.add_argument("--stage", required=True, choices=STAGES)
    parser.add_argument("--cwd", required=True, type=Path)
    parser.add_argument("--source-manifest", required=True, type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a command is required")
    index = STAGES.index(args.stage)
    chain = args.chain.resolve()
    existing = sorted(p.name for p in chain.glob("*.json")) if chain.exists() else []
    receipt_path = chain / f"{index + 1:02d}-{args.stage}.json"
    if receipt_path.exists():
        raise SystemExit("VERIFY_ORDER_VIOLATION: use a new chain after any patch")
    source_hash = hashlib.sha256(args.source_manifest.read_bytes()).hexdigest()
    for row in json.loads(args.source_manifest.read_text()):
        source = args.cwd / row["path"]
        if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != row["sha256"]:
            raise SystemExit("VERIFY_SOURCE_DRIFT: " + row["path"])
    if index:
        previous = chain / f"{index:02d}-{STAGES[index - 1]}.json"
        if not previous.exists():
            raise SystemExit("VERIFY_ORDER_VIOLATION: preceding stage missing")
        receipt = json.loads(previous.read_text())
        if receipt["exit_code"] != 0:
            raise SystemExit("VERIFY_ORDER_VIOLATION: preceding stage failed")
        if receipt["source_manifest_sha256"] != source_hash:
            raise SystemExit("VERIFY_ORDER_VIOLATION: source set changed between stages")
    chain.mkdir(parents=True, exist_ok=True)
    stdout_path = chain / f"{index + 1:02d}-{args.stage}.stdout.log"
    stderr_path = chain / f"{index + 1:02d}-{args.stage}.stderr.log"
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        result = subprocess.run(command, cwd=args.cwd, stdout=stdout, stderr=stderr, check=False)
    receipt = {
        "stage": args.stage,
        "command": command,
        "cwd": str(args.cwd.resolve()),
        "JAVA_HOME": os.environ.get("JAVA_HOME"),
        "source_manifest_sha256": source_hash,
        "prior_receipts": existing,
        "exit_code": result.returncode,
        "stdout_sha256": hashlib.sha256(stdout_path.read_bytes()).hexdigest(),
        "stderr_sha256": hashlib.sha256(stderr_path.read_bytes()).hexdigest(),
    }
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"stage": args.stage, "exit_code": result.returncode,
                      "receipt": str(receipt_path)}))
    if result.returncode:
        print(stderr_path.read_text(errors="replace")[-6000:])
        print(stdout_path.read_text(errors="replace")[-6000:])
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
