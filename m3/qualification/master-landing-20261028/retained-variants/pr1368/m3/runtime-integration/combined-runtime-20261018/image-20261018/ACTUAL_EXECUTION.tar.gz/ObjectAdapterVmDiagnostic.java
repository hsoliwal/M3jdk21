/* Copyright 2026 Hitesh Soliwal and contributors. SPDX-License-Identifier: GPL-2.0-only */
import java.io.Serializable;
import java.lang.reflect.Modifier;

public final class ObjectAdapterVmDiagnostic {
    private static int checks;
    private static final String TOKEN = new String(new char[] {'m', '3'});

    private static final class Adaptable {
        @Override public <T> T toAdapter(Class<T> type) {
            if (type == CharSequence.class) return type.cast(TOKEN);
            return super.toAdapter(type);
        }
        @Override public int hashCode() { return 31337; }
        @Override public boolean equals(Object other) { return other == this; }
        @Override public String toString() { return "adaptable"; }
    }

    private static final class CloneBox implements Cloneable {
        private final Object value;
        CloneBox(Object value) { this.value = value; }
        @Override public CloneBox clone() {
            try { return (CloneBox) super.clone(); }
            catch (CloneNotSupportedException impossible) { throw new AssertionError(impossible); }
        }
    }

    private static void check(boolean actual, String label) {
        checks++;
        if (!actual) throw new AssertionError(label);
    }

    private static void array(Object value, Class<?> exact) {
        check(value.toAdapter(Object.class) == value, "array Object adaptation");
        check(value.toAdapter(exact) == value, "array exact adaptation");
        check(value.toAdapter(Cloneable.class) == value, "array Cloneable adaptation");
        check(value.toAdapter(Serializable.class) == value, "array Serializable adaptation");
        check(value.toAdapter(CharSequence.class) == null, "array mismatch");
        check(value.equals(value) && !value.equals(new Object()), "array equality");
        check(value.hashCode() == System.identityHashCode(value), "array hashCode");
        check(value.toString().startsWith(value.getClass().getName() + "@"), "array toString");
    }

    public static void main(String[] ignored) throws Exception {
        Object plain = new Object();
        check(plain.toAdapter(Object.class) == plain, "default Object adaptation");
        check(plain.toAdapter(CharSequence.class) == null, "default mismatch");
        try { plain.toAdapter(null); throw new AssertionError("null accepted"); }
        catch (NullPointerException expected) { checks++; }
        int flags = Object.class.getDeclaredMethod("toAdapter", Class.class).getModifiers();
        check(Modifier.isPublic(flags) && !Modifier.isFinal(flags) && !Modifier.isStatic(flags), "overridable API");

        Object polymorphic = new Adaptable();
        for (int i = 0; i < 10000; i++) {
            check(polymorphic.toAdapter(CharSequence.class) == TOKEN, "Object-typed override dispatch");
            check(polymorphic.toAdapter(Adaptable.class) == polymorphic, "override super fallback");
            check(polymorphic.hashCode() == 31337, "hashCode virtual dispatch");
            check(polymorphic.equals(polymorphic) && !polymorphic.equals(plain), "equals virtual dispatch");
            check(polymorphic.toString().equals("adaptable"), "toString virtual dispatch");
        }
        int[] primitive = {1, 2, 3};
        String[] reference = {"a", "b"};
        int[][] multi = {{1}, {2}};
        Object[][][] deep = new Object[1][1][1];
        array(primitive, int[].class);
        array(reference, String[].class);
        array(multi, int[][].class);
        array(deep, Object[][][].class);
        int[] primitiveClone = primitive.clone();
        check(primitiveClone != primitive && java.util.Arrays.equals(primitiveClone, primitive), "primitive array clone");
        String[] referenceClone = reference.clone();
        check(referenceClone != reference && java.util.Arrays.equals(referenceClone, reference), "reference array clone");
        int[][] multiClone = multi.clone();
        check(multiClone != multi && multiClone[0] == multi[0], "multidimensional shallow clone");
        CloneBox original = new CloneBox(TOKEN);
        CloneBox copy = original.clone();
        check(copy != original && copy.value == TOKEN, "protected Object clone dispatch");
        System.out.println("OBJECT_ADAPTER_VM_PASS checks=" + checks);
    }
}
