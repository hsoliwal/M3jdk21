from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess

ROOT=Path('/workspace/scratch/f8287c652798/combine/runtime')
WORK=Path('/dev/shm/m3-tq-successor-f8287')
CANONICAL=WORK/'canonical'
B=Path('synexia-openrewrite-recipes/recipe-crates/m3-collections-contract-refinement-20261017')
DATASET='m3-tq-custody-v2-20261018'
BASE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
T='m3/tooling/tq/'
S='m3/tooling/tq-sync/src/main/resources/com/m3/rewrite/backport/jdk21-hash-pinned-text/m3-tq-sync/'
K='src/java.base/share/classes/jdk/internal/mindex/M3TQ.java'
LEGACY='src/main/resources/com/m3/rewrite/backport/jdk21-hash-pinned/jdk22-m3-tq/'
CURRENT='src/main/resources/com/m3/rewrite/backport/jdk21-hash-pinned/m3-tq-current-20261018/'
HISTORY=T+'history/20261018-pre-current-custody/'
before={};after={}
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def js(value): return (json.dumps(value,indent=2)+'\n').encode()
def get(path): return subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
def change(path,data):
    try: original=get(path)
    except subprocess.CalledProcessError: original=None
    if original!=data: before[path]=original;after[path]=data
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
sealed=load_module('existing_sealed',ROOT/'m3/migration/recipe.py')
def seal(plan):
    plan['plan_sha256']=sealed.digest(sealed.canonical({k:v for k,v in plan.items() if k!='plan_sha256'}));return js(plan)

legacy=get(T+LEGACY+'M3TQ.java.txt');current=get(K)
assert sha(legacy)=='d7c3f9fdff0b5f1dcc5272ac4b57962d3f405ec53003b79344361e5515992155'
assert sha(current)=='78aa154b8aa25134edd9a16c746e4fdc7bcd3984b8f76cc96ef81437247e08d4'
change(T+CURRENT+'M3TQ.java.txt',current)
change(T+CURRENT+'manifest.tsv',(K+'\t'+sha(legacy)+'\t'+sha(current)+'\tM3TQ.java.txt\n').encode())

oldplan=get(T+'plan.json');plan=json.loads(oldplan)
change(HISTORY+'plan.json',oldplan)
archive=[]
for row in plan['outputs']:
    for kind in ('before','after'):
        if row[kind] is not None:
            p=row[kind]['resource'];data=get(T+p)
            archive.append({'resource':p,'sha256':sha(data),'git_blob':blob(data),'utf8':data.decode()})
change(HISTORY+'RESOURCES.json',js({'schema':'M3_TQ_LOSSLESS_SOURCE_ARCHIVE_V1','resources':archive}))
change(HISTORY+LEGACY+'manifest.tsv',get(T+LEGACY+'manifest.tsv'))
change(HISTORY+'README.md',b'''<!-- SPDX-License-Identifier: Apache-2.0 -->
# Frozen predecessor custody fixture

The byte-exact predecessor sealed plan and its lossless resource closure (original paths, UTF-8 bytes, hashes and blobs in RESOURCES.json) are retained here. This source archive preserves the original legacy kernel/probe oracle, first-install transitions, mapping authority and guard reconciliation. Its seal and payloads are not rewritten. The archived plan is a frozen source artifact; resources require materialization at their original relative paths before isolated replay. It is not a claim that the current installed runtime equals its historical postimages.
''')
plan['recipe_id']='tq-current-custody-20261018'
kernel=next(r for r in plan['outputs'] if r['path']==K)
kernel['before']=dict(kernel['after'])
kernel['after']={'resource':CURRENT+'M3TQ.java.txt','sha256':sha(current)}
newplan=seal(plan)
change(T+'plan.json',newplan)
change(T+'current-20261018-plan.json',newplan)

p=T+'src/test/java/com/m3/tq/TQTest.java';test=get(p).decode()
test=test.replace('private static final Path GENERATED = OUT.resolve("generated");','private static final Path GENERATED = OUT.resolve("legacy-generated");\n    private static final Path CURRENT_GENERATED = OUT.resolve("generated");')
test=test.replace('private static final String TEXT_RES =','private static final String CURRENT_JAVA_RES = "com/m3/rewrite/backport/jdk21-hash-pinned/m3-tq-current-20261018/";\n    private static final String TEXT_RES =')
test=test.replace('private static List<SourceFile> textAfter;','private static List<SourceFile> textAfter;\n    private static List<SourceFile> currentJavaAfter;')
old='        compileProduct(CURRENT_PATCH,ROOT.resolve(KERNEL),"compile-current-product.log");'
new='''        // Upgrade the retained typed Java kernel through its existing Java recipe owner.
        currentJavaAfter = apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),
                javaAfter.stream().filter(file->file.getSourcePath().toString().equals(KERNEL)).toList());
        assertEquals(1,currentJavaAfter.size());
        assertEquals(KERNEL,currentJavaAfter.getFirst().getSourcePath().toString());
        var currentFiles = new ArrayList<>(currentJavaAfter);
        currentFiles.addAll(javaAfter.stream().filter(file->!file.getSourcePath().toString().equals(KERNEL)).toList());
        currentFiles.addAll(textAfter);
        for (SourceFile file : currentFiles) {
            Path target = CURRENT_GENERATED.resolve(file.getSourcePath()).normalize();
            assertTrue(target.startsWith(CURRENT_GENERATED));
            Files.createDirectories(target.getParent()); Files.writeString(target,file.printAll());
        }
        assertArrayEquals(Files.readAllBytes(ROOT.resolve(KERNEL)),Files.readAllBytes(CURRENT_GENERATED.resolve(KERNEL)));
        compileProduct(CURRENT_PATCH,CURRENT_GENERATED.resolve(KERNEL),"compile-current-product.log");'''
assert test.count(old)==1;test=test.replace(old,new)
old='                ROOT.resolve(TEST+"M3TQTest.java").toString(),'
assert test.count(old)==1;test=test.replace(old,'                CURRENT_GENERATED.resolve(TEST+"M3TQTest.java").toString(),')
marker='    @Test void exactRecipeAndFixedPoint() {'
extra='''    @Test void currentRecipeUpgradeAndFixedPoint() {
        assertEquals(List.of(KERNEL),new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018").targetPaths());
        assertTrue(apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),currentJavaAfter).isEmpty());
        var unrelated = JavaParser.fromJavaVersion().build().parse("class Unrelated { int value() { return 42; } }")
                .findFirst().orElseThrow().withSourcePath(Path.of("src/other/Unrelated.java"));
        var input = new ArrayList<>(javaAfter); input.add(unrelated);
        var result = apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),input);
        assertEquals(1,result.size()); assertEquals(KERNEL,result.getFirst().getSourcePath().toString());
    }

    @Test void currentRecipeRefusesMissingDriftWrongParserDuplicateAndTampering() throws Exception {
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),List.of()));
        var drift = JavaParser.fromJavaVersion().build().parse("class Conflict {}")
                .findFirst().orElseThrow().withSourcePath(Path.of(KERNEL));
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),List.of(drift)));
        var plain = PlainText.builder().sourcePath(Path.of(KERNEL)).text(currentJavaAfter.getFirst().printAll()).build();
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),List.of(plain)));
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018"),
                List.of(currentJavaAfter.getFirst(),currentJavaAfter.getFirst())));
        Path bad = OUT.resolve("test-classes/com/m3/rewrite/backport/jdk21-hash-pinned/m3-tq-current-20261018-bad");
        Files.createDirectories(bad);
        try (var files=Files.list(CRATE.resolve("src/main/resources/"+CURRENT_JAVA_RES))) {
            for (Path file:files.toList()) Files.writeString(bad.resolve(file.getFileName()),Files.readString(file)
                    +(file.toString().endsWith(".java.txt")?"// drift\\n":""));
        }
        assertThrows(IllegalStateException.class,()->new M3Jdk21HashPinnedSnapshotRecipe("m3-tq-current-20261018-bad").getInitialValue(context()));
    }

'''
assert test.count(marker)==1;test=test.replace(marker,extra+marker);change(p,test.encode())
assert get(S+'11-plan.json.txt')==oldplan
assert get(S+'20-TQTest.java.txt')==get(p)
change(S+'11-plan.json.txt',newplan);change(S+'20-TQTest.java.txt',test.encode())
rows=[line.split('\t') for line in get(S+'manifest.tsv').decode().splitlines()]
for row in rows:
    if row[0] in (T+'plan.json',p): row[2]=sha(after[row[0]])
change(S+'manifest.tsv',(''.join('\t'.join(row)+'\n' for row in rows)).encode())
sync=json.loads(get('m3/tooling/tq-sync/plan.json'))
for row in sync['outputs']:
    if row['path'] in (T+'plan.json',p): row['after']['sha256']=sha(after[row['path']])
for path in (T+CURRENT+'manifest.tsv',T+CURRENT+'M3TQ.java.txt',T+'current-20261018-plan.json'):
    assert path not in {r['path'] for r in sync['guards']}
    sync['guards'].append({'path':path,'sha256':sha(after[path])})
change('m3/tooling/tq-sync/plan.json',seal(sync))
change(T+'CURRENT_CUSTODY_20261018.md',b'''<!-- SPDX-License-Identifier: Apache-2.0 -->
# Current kernel custody successor

The existing typed Java snapshot owner independently replaces the retained d7c3 kernel with the exact installed 78aa kernel. Both resources retain their Apache-2.0 notice. The retained legacy oracle, bootstrap, seam/containment mutants and JNI header/library remain bound to legacy-generated. The current oracle compiles the new recipe-produced bytes, first checks exact equality with the installed runtime, and keeps all four Java/JNI execution modes, sparse controls and public/protected API comparisons. The successor adds fixed-point, unrelated-source, missing, drift, parser, duplicate and template-tampering controls.

current-20261018-plan.json is byte-identical to active plan.json and has a versioned recipe identity. The eight-output sealed plan is a current custody/replay fixture with composite historical preimages. It is not an executable upgrade from a fully installed legacy tree. The separate typed Java recipe proves the actual d7c3-to-78aa kernel transition. The runtime source is already its postimage; receipt of this packet does not claim a new kernel write.

The existing plan verifiers, mapping images, Java/text snapshot engines, legacy resources, public interfaces and runtime source remain unchanged. Three exact preinstalled resources close the sync plan dependency set; its24 outputs remain unchanged in count. The prior plan and its lossless resource closure remain frozen under history/20261018-pre-current-custody. Mapping authority chronology remains an independent explicit hold; this packet grants no Matcher, matched-image or full-JDK qualification.
''')

baseline=WORK/'baseline';candidates=WORK/'candidates'
for path,data in after.items():
    dest=candidates/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    if before[path] is not None:
        dest=baseline/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(before[path])
baseline.mkdir(exist_ok=True)
prepare=load_module('existing_prepare',CANONICAL/B/'prepare.py')
metadata=prepare.seal(CANONICAL/B,DATASET,'hsoliwal/M3jdk21',baseline,[candidates],BASE,CANONICAL/'synexia-openrewrite-recipes')
D=CANONICAL/B/'datasets'/DATASET
targets=[]
for path in sorted(after):
    data=before[path];targets.append([path,BASE,'ABSENT' if data is None else blob(data),'ABSENT' if data is None else sha(data),sha(after[path]),'0644','Apache-2.0'])
(D/'TARGETS.tsv').write_text('# target_path\tsource_revision\tsource_git_blob\tbefore_sha256\tafter_sha256\tmode\tlicense\n'+''.join('\t'.join(row)+'\n' for row in targets))
(D/'LINEAGE.json').write_bytes(js({'schema':'M3_TQ_CURRENT_CUSTODY_LINEAGE_V1','baseline':BASE,'retained_kernel':{'path':T+LEGACY+'M3TQ.java.txt','git_blob':blob(legacy),'sha256':sha(legacy),'license':'Apache-2.0'},'current_kernel':{'path':K,'git_blob':blob(current),'sha256':sha(current),'license':'Apache-2.0'},'runtime_target_write':False,'typed_inner_recipe_transition':'retained legacy kernel -> exact current kernel','sealed_plan_role':'composite current custody/replay fixture; not installed-tree upgrade','prior_test_receipt_source_sha256':'c2ecb3b87be0c207a978e30642038dee1a818fb45747ca3d730b08c96c53a2a5','mapping_authority':'HOLD_UNCHANGED','matched_image':'NOT_RUN','matcher_integration':'NOT_RUN'}))
(D/'README.md').write_text('''<!-- SPDX-License-Identifier: Apache-2.0 -->
# Typed current TQ kernel custody

Use the unchanged canonical Java/text snapshot owners. The only Java target is the existing TQ harness; embedded Java resources remain exact resource payloads. Inside that harness, the existing typed Java owner proves retained d7c3→current78aa kernel replacement, fixed point and refusal controls. No runtime kernel write is claimed: target source is already78aa. Legacy resources/tests are preserved and independently compiled. Current compilation consumes exact generated bytes and compares them with installed source first.

The versioned active plan is a composite custody/replay fixture, not an installed-tree upgrade. Archive the predecessor plan byte-exactly and retain every relative resource losslessly with its original path, bytes and hashes. This archive representation is not directly executable before resource materialization. Keep mapping, verifiers, workflows, canonical generic engines and public/runtime sources unchanged. Close three exact current-resource dependencies with sync guards. Mapping chronology stays an explicit independent hold. Previous actual19normal+3sync+19UBSan observations do not automatically qualify this changed harness; execute its actual Java21/JNI and sanitizer lanes after qualified receipt. No image or Matcher qualification is borrowed.

Run the existing Maven crate with this dataset and -Pcontract verify. Retain actual SDK5, sealing8 and receiver9 results. Apply only the existing qualified receiver serially; zero changes on second receipt. All authored payloads preserve first-party Apache-2.0 notices.
''')
(D/'EVALUATION.tsv').write_text('# category\towner_or_candidate\trevision\tdecision\trationale\tqualification\nTYPED_JAVA_KERNEL_SUCCESSOR\tExisting M3Jdk21HashPinnedSnapshotRecipe\t'+BASE+'\tREUSE\tTyped d7c3 to exact78aa replacement with fixed point and refusals\tPENDING_RUNTIME\nLEGACY_ORACLE_CUSTODY\tExisting TQ legacy resources\t'+BASE+'\tPRESERVE\tKeep seam and containment mutants plus JNI probes historical\tPRIOR_19_PLUS_19\nMAPPING_AUTHORITY\tExisting mapping validators\t'+BASE+'\tHOLD\tNo exemption or hash refresh; chronology proof remains separate\tUNCHANGED_REFUSAL\n')
(D/'QUALIFICATION.json').write_bytes(js({'schema':'M3_SOURCE_CANDIDATE_QUALIFICATION_V1','state':'SOURCE_CANDIDATE_SDK_PENDING','dataset':DATASET,'actual_maven_openrewrite_sdk':'NOT_RUN','qualified_receiver':'NOT_RUN','current_harness_runtime':'NOT_RUN','matcher_integration':'NOT_RUN','matched_image':'NOT_RUN','promotion_authority':False}))
(D/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(D))+'\n' for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
(WORK/'packet.json').write_bytes(js({'dataset':DATASET,'baseline':BASE,'canonical_root':str(CANONICAL),'crate':str(CANONICAL/B),'targets':targets,'metadata':metadata}))
print(json.dumps({'dataset':DATASET,'baseline':BASE,'targets':len(targets),'java_targets':metadata['java_targets'],'files':sum(p.is_file() for p in D.rglob('*'))}))
