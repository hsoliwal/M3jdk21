// SPDX-FileCopyrightText: 2026 Hitesh Soliwal and Contributors to the Synexia Project
// SPDX-License-Identifier: Apache-2.0
package com.m3.tq;

import static org.junit.jupiter.api.Assertions.*;

import com.m3.rewrite.backport.M3Jdk21HashPinnedTextSnapshotRecipe;
import com.m3.rewrite.backport.M3Jdk21HashPinnedSnapshotRecipe;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.openrewrite.InMemoryExecutionContext;
import org.openrewrite.Recipe;
import org.openrewrite.SourceFile;
import org.openrewrite.internal.InMemoryLargeSourceSet;
import org.openrewrite.java.JavaParser;
import org.openrewrite.text.PlainText;

final class TQTest {
    private static final Path ROOT = Path.of(System.getProperty("m3.root")).toAbsolutePath().normalize();
    private static final Path CRATE = Path.of(System.getProperty("m3.crate")).toAbsolutePath().normalize();
    private static final Path OUT = CRATE.resolve("target");
    private static final Path GENERATED = OUT.resolve("generated");
    private static final Path PATCH = OUT.resolve("patch");
    private static final Path PROBES = OUT.resolve("probes");
    private static final Path CURRENT_PATCH = OUT.resolve("current-patch");
    private static final Path CURRENT_PROBES = OUT.resolve("current-probes");
    private static final String PRODUCT = "src/java.base/share/classes/";
    private static final String KERNEL = PRODUCT + "jdk/internal/mindex/M3TQ.java";
    private static final String TEST = "test/jdk/java/lang/String/";
    private static final String JAVA_RES = "com/m3/rewrite/backport/jdk21-hash-pinned/jdk22-m3-tq/";
    private static final String TEXT_RES = "com/m3/rewrite/backport/jdk21-hash-pinned-text/m3-tq/";
    private static final String JAVAC = Path.of(System.getProperty("java.home"),"bin/javac").toString();
    private static final String JAVA = Path.of(System.getProperty("java.home"),"bin/java").toString();
    private static final String JAVAP = Path.of(System.getProperty("java.home"),"bin/javap").toString();
    private static List<SourceFile> javaAfter;
    private static List<SourceFile> textAfter;

    private static InMemoryExecutionContext context() {
        return new InMemoryExecutionContext(error -> { throw new IllegalStateException(error); });
    }

    private static List<SourceFile> apply(Recipe recipe, List<SourceFile> before) {
        return recipe.run(new InMemoryLargeSourceSet(before),context(),1).getChangeset()
                .getAllResults().stream().map(result -> result.getAfter()).toList();
    }

    private static List<SourceFile> textBefore() throws Exception {
        var result = new ArrayList<SourceFile>();
        for (String line : Files.readAllLines(CRATE.resolve("src/main/resources/"+TEXT_RES+"manifest.tsv"))) {
            if (line.startsWith("#") || line.isBlank()) continue;
            String[] cells = line.split("\t");
            if (!cells[1].equals("ABSENT")) result.add(PlainText.builder().sourcePath(Path.of(cells[0]))
                    .text(Files.readString(CRATE.resolve("src/main/resources/"+TEXT_RES+cells[3]+".before"))).build());
        }
        return result;
    }

    @BeforeAll static void prepare() throws Exception {
        Files.createDirectories(OUT);
        for (String line : Files.readAllLines(CRATE.resolve("inputs.tsv"))) {
            if (line.startsWith("#") || line.isBlank()) continue;
            String[] fields = line.split("\t");
            assertEquals(fields[1],hash(Files.readAllBytes(ROOT.resolve(fields[0]))),fields[0]);
        }
        javaAfter = apply(new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq"),List.of());
        assertEquals(2,javaAfter.size());
        textAfter = apply(new M3Jdk21HashPinnedTextSnapshotRecipe("m3-tq"),textBefore());
        for (SourceFile file : Stream.concat(javaAfter.stream(),textAfter.stream()).toList()) {
            Path target = GENERATED.resolve(file.getSourcePath()).normalize();
            assertTrue(target.startsWith(GENERATED));
            Files.createDirectories(target.getParent()); Files.writeString(target,file.printAll());
        }
        compileProduct(PATCH,GENERATED.resolve(KERNEL),"compile-product.log");
        Files.createDirectories(PROBES); Files.createDirectories(OUT.resolve("headers"));
        var javac = new ArrayList<>(List.of(JAVAC,"-source","21","-target","21","-proc:none","-Xlint:all","-Werror",
                "--patch-module","java.base="+PATCH,"--add-exports","java.base/jdk.internal.mindex=ALL-UNNAMED",
                "-h",OUT.resolve("headers").toString(),"-d",PROBES.toString(),GENERATED.resolve(TEST+"M3TQTest.java").toString(),
                ROOT.resolve(TEST+"M3MappedStringBackingTest.java").toString(),ROOT.resolve(TEST+"MapFactsTest.java").toString()));
        execute(javac,"compile-probes.log",true);
        compileNative(OUT,false,"compile-native.log");
        compileProduct(CURRENT_PATCH,ROOT.resolve(KERNEL),"compile-current-product.log");
        Files.createDirectories(CURRENT_PROBES);
        // Reuse the exact existing JNI probe and its generated header/library.
        assertArrayEquals(Files.readAllBytes(GENERATED.resolve(TEST+"M3TQTest.java")),
                Files.readAllBytes(ROOT.resolve(TEST+"M3TQTest.java")));
        execute(List.of(JAVAC,"-source","21","-target","21","-proc:none","-Xlint:all","-Werror",
                "--patch-module","java.base="+CURRENT_PATCH,
                "--add-exports","java.base/jdk.internal.mindex=ALL-UNNAMED",
                "-d",CURRENT_PROBES.toString(),
                ROOT.resolve(TEST+"M3TQTest.java").toString(),
                ROOT.resolve(TEST+"M3TQSparseContainmentTest.java").toString(),
                ROOT.resolve(TEST+"M3MappedStringBackingTest.java").toString(),
                ROOT.resolve(TEST+"MapFactsTest.java").toString()),"compile-current-probes.log",true);
    }

    @Test void exactRecipeAndFixedPoint() {
        assertTrue(apply(new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq"),javaAfter).isEmpty());
        assertTrue(apply(new M3Jdk21HashPinnedTextSnapshotRecipe("m3-tq"),textAfter).isEmpty());
    }

    @Test void refusesOccupiedWrongParserAndDuplicateJava() {
        var wrong = JavaParser.fromJavaVersion().build().parse("class Conflict {}")
                .findFirst().orElseThrow().withSourcePath(Path.of(KERNEL));
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq"),List.of(wrong)));
        var plain = PlainText.builder().sourcePath(Path.of(KERNEL)).text(javaAfter.stream()
                .filter(f->f.getSourcePath().toString().equals(KERNEL)).findFirst().orElseThrow().printAll()).build();
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq"),List.of(plain)));
        var duplicate = new ArrayList<>(javaAfter); duplicate.add(javaAfter.getFirst());
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq"),duplicate));
    }

    @Test void refusesTextDriftMissingAndDuplicate() throws Exception {
        var before = textBefore(); assertFalse(before.isEmpty());
        var missing = new ArrayList<>(before); missing.removeFirst();
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedTextSnapshotRecipe("m3-tq"),missing));
        var duplicate = new ArrayList<>(before); duplicate.add(before.getFirst());
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedTextSnapshotRecipe("m3-tq"),duplicate));
        var drift = new ArrayList<>(before);
        drift.set(0,PlainText.builder().sourcePath(before.getFirst().getSourcePath()).text(before.getFirst().printAll()+"drift").build());
        assertThrows(RuntimeException.class,()->apply(new M3Jdk21HashPinnedTextSnapshotRecipe("m3-tq"),drift));
    }

    @Test void preservesUnrelatedSourceAndRejectsTemplateTampering() throws Exception {
        var unrelated = JavaParser.fromJavaVersion().build().parse("class Untouched { int value() { return 42; } }")
                .findFirst().orElseThrow().withSourcePath(Path.of("src/other/Untouched.java"));
        for (SourceFile file : apply(new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq"),List.of(unrelated)))
            assertNotEquals(unrelated.getSourcePath(),file.getSourcePath());
        Path bad = OUT.resolve("test-classes/com/m3/rewrite/backport/jdk21-hash-pinned/jdk22-m3-tq-bad");
        Files.createDirectories(bad);
        try (var files=Files.list(CRATE.resolve("src/main/resources/"+JAVA_RES))) {
            for(Path file:files.toList()) Files.writeString(bad.resolve(file.getFileName()),Files.readString(file)
                    +(file.toString().endsWith(".java.txt")?"// drift\n":""));
        }
        assertThrows(IllegalStateException.class,()->new M3Jdk21HashPinnedSnapshotRecipe("jdk22-m3-tq-bad").getInitialValue(context()));
    }

    @Test void bootstrapInventoryAndModuleBoundary() throws Exception {
        Path classes=OUT.resolve("bootstrap"); Files.createDirectories(classes);
        String base=".m3/openrewrite-recipes/src/main/java/com/synexia/m3/bootstrap/";
        execute(List.of(JAVAC,"--release","21","-proc:none","-Xlint:all","-Werror","-cp",System.getProperty("java.class.path"),
                "-d",classes.toString(),ROOT.resolve(base+"M3BootstrapTaskRecipe.java").toString(),
                ROOT.resolve(base+"M3BootstrapInventoryRecipe.java").toString()),"compile-bootstrap.log",true);
        String oldFile=System.getProperty("m3.llm.taskCrateFile"),oldHash=System.getProperty("m3.llm.taskCrateRoot");
        Path manifest=CRATE.resolve("src/main/resources/"+JAVA_RES+"manifest.tsv");
        try(var loader=new URLClassLoader(new java.net.URL[]{classes.toUri().toURL()},TQTest.class.getClassLoader())) {
            System.setProperty("m3.llm.taskCrateFile",manifest.toString());
            System.setProperty("m3.llm.taskCrateRoot",hash(Files.readAllBytes(manifest)));
            var type=loader.loadClass("com.synexia.m3.bootstrap.M3BootstrapTaskRecipe");
            Recipe recipe=(Recipe)type.getConstructor().newInstance();
            assertEquals(false,type.getMethod("directTargetFileMutationAuthority").invoke(recipe));
            assertTrue(apply(recipe,javaAfter).isEmpty());
            System.setProperty("m3.llm.taskCrateRoot","0".repeat(64));
            assertThrows(IllegalStateException.class,recipe::getRecipeList);
        } finally {
            if(oldFile==null)System.clearProperty("m3.llm.taskCrateFile");else System.setProperty("m3.llm.taskCrateFile",oldFile);
            if(oldHash==null)System.clearProperty("m3.llm.taskCrateRoot");else System.setProperty("m3.llm.taskCrateRoot",oldHash);
        }
        execute(List.of(Path.of(System.getProperty("java.home"),"bin/jdeps").toString(),"-s",PATCH.toString()),"jdeps.log",true);
        assertEquals("patch -> java.base",Files.readString(OUT.resolve("jdeps.log")).strip());
    }

    @TestFactory Stream<DynamicTest> runtimeModes() {
        return Stream.of("interpreter","mixed","c1","c2").map(mode->DynamicTest.dynamicTest(mode,()->{
            List<String> command=runtime(PATCH,OUT,"M3TQTest");
            if(mode.equals("interpreter"))command.add(1,"-Xint");
            if(mode.equals("c1")||mode.equals("c2")) {
                command.add(1,"-XX:CompileCommand=dontinline,jdk.internal.mindex.M3TQ$Facts::containsAll");
                command.addAll(1,List.of("-Xbatch","-XX:CompileThreshold=100","-XX:+UnlockDiagnosticVMOptions","-XX:+LogCompilation",
                        "-XX:LogFile="+OUT.resolve(mode+"-compilation.xml")));
                command.add(1,mode.equals("c1")?"-XX:TieredStopAtLevel=1":"-XX:-TieredCompilation");
            }
            execute(command,mode+".log",true);
            assertTrue(Files.readString(OUT.resolve(mode+".log")).contains("warmPayloadReads=0"));
            if(mode.equals("c1")||mode.equals("c2")) {
                String log=Files.readString(OUT.resolve(mode+"-compilation.xml"));
                assertTrue(log.lines().anyMatch(l->l.contains("<nmethod")&&l.contains("compiler='"+mode+"'")
                        &&l.contains("method='jdk.internal.mindex.M3TQ$Facts containsAll ")),"containment compiled by "+mode);
                assertTrue(log.lines().anyMatch(l->l.contains("<nmethod")&&l.contains("compiler='"+mode+"'")
                        &&l.contains("method='jdk.internal.mindex.M3TQ ")),"kernel compiled by "+mode);
            }
        }));
    }

    @Test void unchangedMappedRegressions() throws Exception {
        execute(runtime(PATCH,OUT,"M3MappedStringBackingTest"),"original-mapped.log",true);
        execute(runtime(PATCH,OUT,"MapFactsTest"),"original-facts.log",true);
    }

    @Test void rejectsNativeUnicodeMutant() throws Exception {
        Path directory=OUT.resolve("native-mutant");Files.createDirectories(directory);
        compileNative(directory,true,"native-mutant-compile.log");
        execute(runtime(PATCH,directory,"M3TQTest"),"native-mutant.log",false);
        assertTrue(Files.readString(OUT.resolve("native-mutant.log")).contains("AssertionError: native"));
    }

    @Test void rejectsJavaSeamMutant() throws Exception {
        Path source=OUT.resolve("seam-mutant/M3TQ.java");Files.createDirectories(source.getParent());
        String original=Files.readString(GENERATED.resolve(KERNEL));
        assertTrue(original.contains("long[] seam = seamKeys(right);"));
        Files.writeString(source,original.replace("long[] seam = seamKeys(right);","long[] seam = new long[0];"));
        Path patch=OUT.resolve("seam-mutant-patch");
        compileProduct(patch,source,"seam-mutant-compile.log");
        execute(runtime(patch,OUT,"M3TQTest"),"seam-mutant.log",false);
        assertTrue(Files.readString(OUT.resolve("seam-mutant.log")).contains("AssertionError: seam composition"));
    }

    @Test void rejectsContainmentMutant() throws Exception {
        Path source=OUT.resolve("containment-mutant/M3TQ.java");Files.createDirectories(source.getParent());
        String original=Files.readString(GENERATED.resolve(KERNEL));
        assertTrue(original.contains("return needle == required.keys.length;"));
        Files.writeString(source,original.replace("return needle == required.keys.length;","return true;"));
        Path patch=OUT.resolve("containment-mutant-patch");
        compileProduct(patch,source,"containment-mutant-compile.log");
        execute(runtime(patch,OUT,"M3TQTest"),"containment-mutant.log",false);
        assertTrue(Files.readString(OUT.resolve("containment-mutant.log")).contains("AssertionError: containment set oracle"));
    }


    @TestFactory Stream<DynamicTest> currentRuntimeModes() {
        return Stream.of("interpreter","mixed","c1","c2")
                .map(mode -> DynamicTest.dynamicTest("current-"+mode,() -> {
            for(String main:List.of("M3TQTest","M3TQSparseContainmentTest")) {
                String stem="current-"+mode+"-"+main;
                List<String> command=runtime(CURRENT_PATCH,OUT,CURRENT_PROBES,main);
                command.addAll(1,List.of("--add-opens","java.base/jdk.internal.mindex=ALL-UNNAMED"));
                if(mode.equals("interpreter"))command.add(1,"-Xint");
                if(mode.equals("mixed"))command.add(1,"-Xmixed");
                if(mode.equals("c1")||mode.equals("c2")) {
                    command.addAll(1,List.of("-Xbatch","-XX:CompileThreshold=100",
                            "-XX:+UnlockDiagnosticVMOptions","-XX:+LogCompilation",
                            "-XX:LogFile="+OUT.resolve(stem+"-compilation.xml"),
                            "-XX:CompileCommand=dontinline,jdk.internal.mindex.M3TQ$Facts::containsAll"));
                    command.add(1,mode.equals("c1")?"-XX:TieredStopAtLevel=1":"-XX:-TieredCompilation");
                }
                execute(command,stem+".log",true);
                String output=Files.readString(OUT.resolve(stem+".log"));
                assertTrue(output.contains("warmPayloadReads=0"));
                if(main.equals("M3TQTest")) {
                    assertTrue(output.contains("TQ checks=308649 "));
                    assertTrue(output.contains("nativeCalls=4458 "));
                } else {
                    assertTrue(output.contains("TQ_SPARSE_CONTAINMENT_PASS checks=31011 warmPayloadReads=0"));
                }
                if(mode.equals("c1")||mode.equals("c2")) {
                    String log=Files.readString(OUT.resolve(stem+"-compilation.xml"));
                    assertTrue(log.lines().anyMatch(line -> line.contains("<nmethod")
                            &&line.contains("compiler='"+mode+"'")
                            &&line.contains("method='jdk.internal.mindex.M3TQ$Facts containsAll ")),
                            "current containment compiled by "+mode);
                    if(main.equals("M3TQTest")) {
                        assertTrue(log.lines().anyMatch(line -> line.contains("<nmethod")
                                &&line.contains("compiler='"+mode+"'")
                                &&line.contains("method='jdk.internal.mindex.M3TQ ")),
                                "current kernel compiled by "+mode);
                    }
                }
            }
        }));
    }

    @Test void currentPublicProtectedApiMatchesLegacy() throws Exception {
        for(String name:List.of("M3TQ","M3TQ$Facts","M3TQ$Op")) {
            String relative="jdk/internal/mindex/"+name+".class";
            String stem="api-"+name.replace('$','-');
            execute(List.of(JAVAP,"-protected","-s",PATCH.resolve(relative).toString()),
                    stem+"-legacy.log",true);
            execute(List.of(JAVAP,"-protected","-s",CURRENT_PATCH.resolve(relative).toString()),
                    stem+"-current.log",true);
            assertEquals(Files.readString(OUT.resolve(stem+"-legacy.log")),
                    Files.readString(OUT.resolve(stem+"-current.log")),name+" public/protected API");
        }
    }

    @Test void currentMappedRegressionsAndModuleBoundary() throws Exception {
        execute(runtime(CURRENT_PATCH,OUT,CURRENT_PROBES,"M3MappedStringBackingTest"),
                "current-mapped.log",true);
        execute(runtime(CURRENT_PATCH,OUT,CURRENT_PROBES,"MapFactsTest"),"current-facts.log",true);
        execute(List.of(Path.of(System.getProperty("java.home"),"bin/jdeps").toString(),
                "-s",CURRENT_PATCH.toString()),"current-jdeps.log",true);
        assertEquals("current-patch -> java.base",Files.readString(OUT.resolve("current-jdeps.log")).strip());
    }

    private static void compileProduct(Path output,Path kernel,String log) throws Exception {
        Files.createDirectories(output);
        Path isolated=output.resolveSibling(output.getFileName()+"-sources");
        Path owner=isolated.resolve("jdk/internal/mindex");Files.createDirectories(owner);
        Files.copy(kernel,owner.resolve("M3TQ.java"),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        for(String name:List.of("M3StringBacking","M3MappedStringBacking"))
            Files.copy(ROOT.resolve(PRODUCT+"jdk/internal/mindex/"+name+".java"),owner.resolve(name+".java"),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        execute(List.of(JAVAC,"-source","21","-target","21","-proc:none","-implicit:none","-Xlint:all","-Werror",
                "--patch-module","java.base="+isolated,"-d",output.toString(),
                owner.resolve("M3TQ.java").toString(),owner.resolve("M3StringBacking.java").toString(),
                owner.resolve("M3MappedStringBacking.java").toString()),log,true);
    }

    private static void compileNative(Path directory,boolean mutant,String log) throws Exception {
        Path javaHome=Path.of(System.getProperty("java.home"));
        var command=new ArrayList<>(List.of("g++","-std=c++17","-O2","-Wall","-Wextra","-Werror","-Wconversion","-Wshadow","-Wpedantic",
                "-fPIC","-shared","-I"+javaHome.resolve("include"),"-I"+javaHome.resolve("include/linux"),
                "-include",OUT.resolve("headers/M3TQTest.h").toString()));
        if(Boolean.getBoolean("tq.sanitize"))command.addAll(List.of("-fsanitize=undefined","-fno-sanitize-recover=all"));
        if(mutant)command.add("-DM3_MUTANT_8BIT");
        command.addAll(List.of(GENERATED.resolve(TEST+"libM3TQTest.cpp").toString(),"-o",directory.resolve("libM3TQTest.so").toString()));
        execute(command,log,true);
    }

    private static List<String> runtime(Path patch,Path nativePath,String main) {
        return runtime(patch,nativePath,PROBES,main);
    }

    private static List<String> runtime(Path patch,Path nativePath,Path probeClasses,String main) {
        return new ArrayList<>(List.of(JAVA,"-Xmx256m","-Xcheck:jni","--patch-module","java.base="+patch,
                "--add-exports","java.base/jdk.internal.mindex=ALL-UNNAMED","-Djava.library.path="+nativePath,
                "-cp",probeClasses.toString(),main));
    }

    private static String hash(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }

    private static void execute(List<String> command,String log,boolean success) throws Exception {
        Path output=OUT.resolve(log);
        Process process=new ProcessBuilder(command).redirectErrorStream(true).redirectOutput(output.toFile()).start();
        if(!process.waitFor(60,TimeUnit.SECONDS)){process.destroyForcibly();fail("timeout: "+log);}
        if(success) assertEquals(0,process.exitValue(),()->{try{return Files.readString(output);}catch(Exception e){return e.toString();}});
        else assertNotEquals(0,process.exitValue(),"mutant must fail");
    }
}
