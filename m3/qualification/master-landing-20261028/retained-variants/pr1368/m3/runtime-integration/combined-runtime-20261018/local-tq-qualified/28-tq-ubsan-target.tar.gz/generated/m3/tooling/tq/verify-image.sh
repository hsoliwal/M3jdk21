#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Linux image qualification. No patch-module: use the built fork's java.base.
set -euo pipefail
root=$(cd "$(dirname "$0")/../../.." && pwd)
: "${M3_TEST_JDK:?Set the absolute path of the freshly built fastdebug M3JDK image}"
image=$(cd "$M3_TEST_JDK" && pwd)
out="$root/m3/tooling/tq/target/image"
mkdir -p "$out/classes" "$out/headers"
"$image/bin/java" -version > "$out/version.log" 2>&1
if ! grep -q fastdebug "$out/version.log"; then
  echo 'A matching fastdebug fork image is required' >&2
  exit 2
fi
testdir="$root/test/jdk/java/lang/String"
"$image/bin/javac" -source 21 -target 21 -proc:none -Xlint:all -Werror \
  --add-exports java.base/jdk.internal.mindex=ALL-UNNAMED \
  -h "$out/headers" -d "$out/classes" "$testdir/M3TQTest.java" \
  "$testdir/M3MappedStringBackingTest.java" "$testdir/MapFactsTest.java" \
  > "$out/javac.log" 2>&1
g++ -std=c++17 -O2 -Wall -Wextra -Werror -Wconversion -Wshadow -Wpedantic \
  -fPIC -shared -I"$image/include" -I"$image/include/linux" \
  -include "$out/headers/M3TQTest.h" "$testdir/libM3TQTest.cpp" \
  -o "$out/libM3TQTest.so" > "$out/native.log" 2>&1
for mode in interpreter mixed c1 c2 m3-c1 m3-c2 m3-c2-nocompact; do
  flags=()
  compiler=''
  case "$mode" in
    interpreter) flags+=(-Xint);;
    c1|m3-c1) compiler=c1; flags+=(-XX:TieredStopAtLevel=1);;
    c2|m3-c2|m3-c2-nocompact) compiler=c2; flags+=(-XX:-TieredCompilation);;
  esac
  if [[ -n "$compiler" ]]; then
    flags+=('-XX:CompileCommand=dontinline,jdk.internal.mindex.M3TQ$Facts::containsAll'
      -Xbatch -XX:CompileThreshold=100 -XX:+UnlockDiagnosticVMOptions
      -XX:+LogCompilation "-XX:LogFile=$out/$mode-compilation.xml")
  fi
  if [[ "$mode" == m3-* ]]; then
    flags+=(-XX:+UnlockExperimentalVMOptions -XX:+UseM3StringStorage)
  fi
  if [[ "$mode" == *-nocompact ]]; then flags+=(-XX:-CompactStrings); fi
  for main in M3TQTest M3MappedStringBackingTest MapFactsTest; do
    # Keep kernel compilation evidence separate from unchanged regression runs.
    runflags=("${flags[@]}")
    if [[ -n "$compiler" && "$main" != M3TQTest ]]; then
      runflags+=("-XX:LogFile=$out/$mode-$main-compilation.xml")
    fi
    timeout 240 "$image/bin/java" -Xmx256m -ea -esa -Xcheck:jni \
      -XX:-CreateCoredumpOnCrash "${runflags[@]}" \
      --add-exports java.base/jdk.internal.mindex=ALL-UNNAMED \
      "-Djava.library.path=$out" -cp "$out/classes" "$main" \
      > "$out/$mode-$main.log" 2>&1
  done
  grep -q 'warmPayloadReads=0' "$out/$mode-M3TQTest.log"
  if [[ -n "$compiler" ]]; then
    evidence_flags=()
    if [[ "$mode" == m3-* ]]; then evidence_flags+=(--m3-interpreter); fi
    python3 "$root/m3/tooling/lane28/check-log.py" \
      "$out/$mode-compilation.xml" "$compiler" jdk.internal.mindex.M3TQ "${evidence_flags[@]}"
    python3 "$root/m3/tooling/lane28/check-log.py" \
      "$out/$mode-compilation.xml" "$compiler" 'jdk.internal.mindex.M3TQ$Facts containsAll' "${evidence_flags[@]}"
  fi
done
echo 'PASS: TQ and mapped-owner parity, normal compiled kernels and retained M3 interpreter boundary'
